/**
 * 初始化本地 MySQL 数据库：建库、建表、导入曲库种子数据。
 * 用法：npm run init-db （可重复执行，目录数据刷新，用户数据保留）
 * 连接参数可通过环境变量 MYSQL_HOST / MYSQL_PORT / MYSQL_USER / MYSQL_PASSWORD / MYSQL_DB 覆盖。
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import mysql from 'mysql2/promise'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8')).mysql
const readJson = (p, fallback) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')) } catch { return fallback } }

const opts = {
  host: process.env.MYSQL_HOST || cfg.host,
  port: Number(process.env.MYSQL_PORT || cfg.port),
  user: process.env.MYSQL_USER || cfg.user,
  password: process.env.MYSQL_PASSWORD ?? cfg.password,
  charset: 'utf8mb4'
}
const dbName = process.env.MYSQL_DB || cfg.database

const conn = await mysql.createConnection(opts)
console.log(`[MySQL] 连接 ${opts.host}:${opts.port} ...`)

await conn.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`)
await conn.query(`USE \`${dbName}\``)

const ddl = [
  `CREATE TABLE IF NOT EXISTS meta (
    meta_key VARCHAR(64) PRIMARY KEY,
    meta_value TEXT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS categories (
    name VARCHAR(64) PRIMARY KEY,
    sort_order INT NOT NULL DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS audio_zone_categories (
    name VARCHAR(64) PRIMARY KEY,
    sort_order INT NOT NULL DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS songs (
    id INT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    artist VARCHAR(255) DEFAULT '',
    album VARCHAR(255) DEFAULT '',
    category VARCHAR(64) DEFAULT '',
    src TEXT,
    cover TEXT,
    duration INT DEFAULT 0,
    quality VARCHAR(32) DEFAULT '',
    \`year\` INT DEFAULT 0,
    play_count BIGINT DEFAULT 0,
    tags JSON
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE INDEX idx_songs_category ON songs(category)`,
  `CREATE INDEX idx_songs_title ON songs(title)`,
  `CREATE TABLE IF NOT EXISTS lyrics (
    song_id INT PRIMARY KEY,
    content LONGTEXT
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS accompaniments (
    id INT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    original_song_id INT DEFAULT 0,
    artist VARCHAR(255) DEFAULT '',
    category VARCHAR(64) DEFAULT '',
    src TEXT,
    cover TEXT,
    duration INT DEFAULT 0,
    bpm INT DEFAULT 0,
    musical_key VARCHAR(16) DEFAULT '',
    quality VARCHAR(64) DEFAULT '',
    has_guide_vocal TINYINT DEFAULT 0,
    play_count BIGINT DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE INDEX idx_acc_category ON accompaniments(category)`,
  `CREATE TABLE IF NOT EXISTS audio_zone (
    id INT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(64) DEFAULT '',
    host VARCHAR(255) DEFAULT '',
    description TEXT,
    src TEXT,
    cover TEXT,
    duration INT DEFAULT 0,
    episodes INT DEFAULT 0,
    play_count BIGINT DEFAULT 0,
    tags JSON
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE INDEX idx_az_category ON audio_zone(category)`,
  `CREATE TABLE IF NOT EXISTS playlists (
    id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(64) DEFAULT '',
    cover TEXT,
    description TEXT,
    tags JSON
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS effects (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) DEFAULT '',
    icon VARCHAR(32) DEFAULT '',
    description TEXT,
    params JSON
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS charts (
    chart_key VARCHAR(32) PRIMARY KEY,
    song_ids JSON
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(64) NOT NULL UNIQUE,
    phone VARCHAR(32) DEFAULT '',
    password VARCHAR(255) NOT NULL,
    nickname VARCHAR(128) DEFAULT '',
    signature TEXT,
    gender VARCHAR(16) DEFAULT 'secret',
    birthday VARCHAR(32) DEFAULT '',
    city VARCHAR(128) DEFAULT '',
    email VARCHAR(128) DEFAULT '',
    avatar VARCHAR(64) DEFAULT '',
    background TEXT,
    play_count INT DEFAULT 0,
    role VARCHAR(32) DEFAULT 'user',
    created_at VARCHAR(64) DEFAULT ''
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS user_state (
    state_key VARCHAR(64) PRIMARY KEY,
    payload JSON
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS local_tracks (
    id VARCHAR(32) PRIMARY KEY,
    path TEXT NOT NULL,
    name VARCHAR(512) DEFAULT '',
    title VARCHAR(512) DEFAULT '',
    artist VARCHAR(512) DEFAULT '',
    album VARCHAR(512) DEFAULT '',
    size BIGINT DEFAULT 0,
    mtime VARCHAR(64) DEFAULT '',
    cover TEXT,
    added_at VARCHAR(64) DEFAULT ''
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS jamendo_tracks (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(512) DEFAULT '',
    artist VARCHAR(512) DEFAULT '',
    album VARCHAR(512) DEFAULT '',
    genre VARCHAR(128) DEFAULT '',
    audio TEXT,
    image TEXT,
    duration INT DEFAULT 0,
    popularity BIGINT DEFAULT 0,
    synced_at VARCHAR(64) DEFAULT ''
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE INDEX idx_jamendo_genre ON jamendo_tracks(genre)`
]
for (const sql of ddl) {
  try { await conn.query(sql) }
  catch (e) { if (!/Duplicate key name|already exists/i.test(e.message)) throw e }
}
console.log('[MySQL] 表结构就绪')

/** 批量写入：目录数据每次刷新，用户数据用 INSERT IGNORE 保留 */
async function bulk(table, columns, rows, overwrite = true) {
  if (!rows.length) return 0
  for (let i = 0; i < rows.length; i += 100) {
    const chunk = rows.slice(i, i + 100)
    const marks = chunk.map(() => `(${columns.map(() => '?').join(',')})`).join(',')
    let sql = `INSERT ${overwrite ? '' : 'IGNORE '}INTO \`${table}\` (${columns.map((c) => `\`${c}\``).join(',')}) VALUES ${marks}`
    if (overwrite) {
      const updates = columns.filter((c) => c !== 'id' && c !== 'song_id' && c !== 'chart_key' && c !== 'meta_key' && c !== 'name')
      sql += ` ON DUPLICATE KEY UPDATE ${updates.map((c) => `\`${c}\`=VALUES(\`${c}\`)`).join(',')}`
    }
    await conn.query(sql, chunk.flatMap((r) => columns.map((c) => r[c] ?? null)))
  }
  return rows.length
}

const catalog = readJson(path.join(ROOT, 'data/catalog.json'), {})
const J = (v) => JSON.stringify(v ?? [])

const counts = {}
counts.categories = await bulk('categories', ['name', 'sort_order'], catalog.categories.map((name, i) => ({ name, sort_order: i })))
counts.audio_zone_categories = await bulk('audio_zone_categories', ['name', 'sort_order'], catalog.audioZoneCategories.map((name, i) => ({ name, sort_order: i })))
counts.songs = await bulk('songs',
  ['id', 'title', 'artist', 'album', 'category', 'src', 'cover', 'duration', 'quality', 'year', 'play_count', 'tags'],
  catalog.songs.map((s) => ({ ...s, play_count: s.playCount, tags: J(s.tags) })))
counts.lyrics = await bulk('lyrics', ['song_id', 'content'],
  Object.entries(catalog.lyrics || {}).map(([id, l]) => ({ song_id: Number(id), content: l.content || '' })))
counts.accompaniments = await bulk('accompaniments',
  ['id', 'title', 'original_song_id', 'artist', 'category', 'src', 'cover', 'duration', 'bpm', 'musical_key', 'quality', 'has_guide_vocal', 'play_count'],
  catalog.accompaniments.map((a) => ({ ...a, original_song_id: a.originalSongId, musical_key: a.key, has_guide_vocal: a.hasGuideVocal ? 1 : 0, play_count: a.playCount })))
counts.audio_zone = await bulk('audio_zone',
  ['id', 'title', 'category', 'host', 'description', 'src', 'cover', 'duration', 'episodes', 'play_count', 'tags'],
  catalog.audioZone.map((a) => ({ ...a, description: a.desc, play_count: a.playCount, tags: J(a.tags) })))
counts.playlists = await bulk('playlists', ['id', 'name', 'category', 'cover', 'description', 'tags'],
  catalog.playlists.map((p) => ({ ...p, tags: J(p.tags) })))
counts.effects = await bulk('effects', ['id', 'name', 'icon', 'description', 'params'],
  catalog.effects.map((e) => ({ ...e, description: e.desc, params: J(e.params) })))
counts.charts = await bulk('charts', ['chart_key', 'song_ids'],
  Object.entries(catalog.charts || {}).map(([k, ids]) => ({ chart_key: k, song_ids: J(ids) })))

// 用户账号：首次从 users.json 迁移，之后保留库中数据（不覆盖用户改过的资料）
const users = readJson(path.join(ROOT, 'data/users.json'), [])
counts.users = await bulk('users',
  ['id', 'username', 'phone', 'password', 'nickname', 'signature', 'gender', 'birthday', 'city', 'email', 'avatar', 'background', 'play_count', 'role', 'created_at'],
  users.map((u) => ({ ...u, play_count: u.playCount || 0, created_at: u.createdAt || '' })), false)

// 用户交互数据：按模块存 JSON，重复执行保留已有数据
const defaultState = {
  favorites: { 1: [], 2: [] },
  playlists: [],
  history: { 1: [], 2: [] },
  recordings: [],
  sleepTimers: {},
  playerSettings: {},
  recognitionLog: []
}
const oldState = readJson(path.join(ROOT, 'data/userdata.json'), {})
const state = { ...defaultState, ...oldState }
counts.user_state = await bulk('user_state', ['state_key', 'payload'],
  Object.entries(state).map(([state_key, value]) => ({ state_key, payload: J(value) })), false)

await bulk('meta', ['meta_key', 'meta_value'], [
  { meta_key: 'schema_version', meta_value: '1' },
  { meta_key: 'imported_at', meta_value: new Date().toISOString() }
])

console.log('[MySQL] 导入完成：')
for (const [k, v] of Object.entries(counts)) console.log(`  ${k.padEnd(22)} ${v} 行`)
console.log(`[MySQL] 数据库 ${dbName} 已就绪 ✓`)
await conn.end()
