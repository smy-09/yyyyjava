/**
 * 曲库种子生成器
 * 生成歌曲 / 伴奏 / 有声专区 / 歌词 / 歌单 / 音效预设 等数据到 data/catalog.json
 * 运行: node scripts/seed.js
 *
 * 说明：音频源使用公开的免费示例音频（SoundHelix），仅用于演示播放器交互；
 *      真实商业曲库需要接入有版权授权的音频 CDN。
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DATA_DIR = path.resolve(__dirname, '../data')

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */
function seededRandom(seed) {
  let s = seed >>> 0
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0
    return s / 4294967296
  }
}
const rnd = seededRandom(20261127)
const pick = (arr) => arr[Math.floor(rnd() * arr.length)]
const pickN = (arr, n) => {
  const copy = arr.slice()
  const out = []
  while (copy.length && out.length < n) out.push(copy.splice(Math.floor(rnd() * copy.length), 1)[0])
  return out
}
const between = (a, b) => a + Math.floor(rnd() * (b - a + 1))

const AUDIO_POOL = Array.from({ length: 16 }, (_, i) =>
  `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${i + 1}.mp3`
)

const GRADIENTS = [
  ['#1ec8ff', '#7b5cff'], ['#ff8a5b', '#ff5b8a'], ['#22d3a6', '#1e8bff'],
  ['#f6c453', '#ff7e5f'], ['#a06bff', '#ff6bcb'], ['#3ad1ff', '#2e6cff'],
  ['#ff5b8a', '#ffb15b'], ['#5be0a0', '#1ec8ff'], ['#ff7e5f', '#a06bff'],
  ['#4facfe', '#00f2fe'], ['#f7971e', '#ffd200'], ['#43e97b', '#38f9d7']
]
const coverGradient = (id) => {
  const [a, b] = GRADIENTS[id % GRADIENTS.length]
  return `linear-gradient(135deg,${a},${b})`
}

/* ------------------------------------------------------------------ */
/* 曲库内容池                                                          */
/* ------------------------------------------------------------------ */
const SONG_SEED = {
  '华语': {
    titles: ['青花瓷', '夜曲', '晴天', '稻香', '双截棍', '七里香', '告白气球', '简单爱', '东风破', '千里之外',
      '菊花台', '枫', '搁浅', '以父之名', '听妈妈的话', '爱在西元前', '龙卷风', '安静', '彩虹', '甜甜的',
      '不能说的秘密', '蒲公英的约定', '说好的幸福呢', '兰亭序', '红尘客栈', '明明就', '手写的从前', '烟花易冷',
      'love me', '依然范特西', '爱情转移', '富士山下', '十年', '明年今日', 'K歌之王', '爱情呼叫转移',
      '红豆', '约定', '暗涌', 'shall we talk', '岁月如歌', '漫步人生路', '牵挂', '你是我的眼'],
    artists: ['周杰伦', '林俊杰', '陈奕迅', '王力宏', '陶喆', '蔡依林', '孙燕姿', '梁静茹', '五月天', '张惠妹', '薛之谦', '李荣浩'],
    albums: ['叶惠美', '范特西', '依然范特西', '认识你', '黑柳', 'Reverse', '明天 albums', '伟大意志', '小情歌']
  },
  '流行': {
    titles: ['孤勇者', '起风了', '可能', '芒种', '下山', '发烧', '句号', '光年之外', '倒数', '简单爱',
      '大鱼', '灯火里的中国', '万疆', '听我说谢谢你', '热爱','兰亭序', '少年', '你的答案', '沙漠骆驼', '隔壁泰山',
      '学猫叫', '纸短情长', '西装暴徒', '陷阱', '漫步人生路', '年少有为', '李白', '我们的时光', '成全', '征服',
      '追光者', '日常', '侧脸', '白皮书', '畅销', '无名之辈', '一生和你', '我曾', 'Something Just Like This'],
    artists: ['陈奕迅', '张韶涵', '毛不易', '李荣浩', '薛之谦', '周深', '张碧晨', '邓紫棋', '华晨宇', '五月天', '田馥甄', '林俊杰'],
    albums: ['流行先锋', '热歌精选', '新歌速递', '华语流行榜', '金曲合集', '都市心情']
  },
  'DJ': {
    titles: ['野狼disco', '海草舞', 'C哩C哩', '惊雷', '海浪', '社会摇', '蹦迪专用', '电音之王', 'Faded 中文版',
      'DJ版小苹果', '夜店嗨曲', '摇啊摇', '动感超人', '节奏风暴', '电音轰炸', '重低音串烧', '慢摇精选',
      '午夜DJ', '狂欢派对', '抖音神曲串烧', '全场嗨翻', '夜场必备', '电音狂潮', '舞动奇迹', '动感节拍',
      '劲爆嗨曲', '超燃串烧', 'DJ阿卓', '摇子', '蹦擦擦', '电摇', '炸街神曲', '车载嗨曲', '电音嘉年华'],
    artists: ['DJ阿卓', 'DJ小鱼儿', 'DJ伟然', 'DJ何鹏', 'DJ王志', 'DJ阿圣', 'DJ默涵', 'DJ浪子'],
    albums: ['DJ嗨曲集', '夜店舞曲', '重低音专区', '车载DJ', '电音派对']
  },
  '老歌': {
    titles: ['月亮代表我的心', '甜蜜蜜', '小城故事', '恰似你的温柔', '光阴的故事', '朋友', '恋曲1990', '一剪梅',
      '大约在冬季', '明天你是否依然爱我', '我只在乎你', '漫步人生路', '千言万语', '何日君再来', '夜来香',
      '不了情', '今生缘', '旧梦', '昨日重现', '忘情水', '男人哭吧不是罪', '中国人', '故乡的云', '冬天里的一把火',
      '让我们荡起双桨', '难忘今宵', '我的祖国', '英雄赞歌', '弹起我心爱的土琵琶', '太阳最红', '一无所有',
      '故乡', '光阴的故事', '爱的奉献', '真心英雄', '相约一九九八', '为了谁', '举杯吧朋友', '祝酒歌'],
    artists: ['邓丽君', '罗大佑', '齐秦', '费玉清', '刘德华', '张学友', '郭兰英', '崔健', '李谷一', '毛宁', '那英', '孙楠'],
    albums: ['经典老歌', '怀旧金曲', '岁月留声', '老歌精选', '时光回声']
  },
  '民谣': {
    titles: ['平凡之路', '斑马斑马', '南山南', '成都', '理想', '当你老了', '小半', '南方姑娘', '天空之城',
      '奇妙能力歌', '董小姐', '安河桥', '清欢', '归去来兮', '无问西东', '我们的时代', '不说', '旧巷',
      '七月上', '阿刁', '崇拜', '大冰', '偏差', '多想在平庸的生活拥抱你', '出山', '九月', '米店',
      '关于郑州的记忆', '和你在一起', '山茶花', '鹿先森', '纸短情长', '我已不习惯没有你', '如今年代',
      '太阳', '旅程', '那些事儿', '老街', '定西', '普通disCo'],
    artists: ['朴树', '宋冬野', '马頔', '赵雷', '毛不易', '老狼', '房东的猫', '陈鸿宇', '花粥', '十三月', '鹿先森乐队', '陈粒'],
    albums: ['民谣在路上', '民谣精选', '清新民谣', '诗与远方', '城市民谣']
  },
  '摇滚': {
    titles: ['海阔天空', '光辉岁月', '真的爱你', '怒放的生命', '存在', '北京北京', '春天里', '夜空中最亮的星',
      '蓝莲花', '一无所有', '新长征路上的摇滚', '假行僧', '花房姑娘', '快让我在雪地上撒点野', '晚安北京',
      '公路之歌', '我们的时光', '再见梦想', '自由', '塑造', '晚风', '公路之歌', '永远年轻',
      '当','逆风', '破晓', '燃烧', '倔强', '知足', '温柔', '生命之诗', '显示器', '海阔天空',
      '金属狂潮', '朋克少年', '摇滚不死', '节奏与暴力', '暴雨将至', '新的出发'],
    artists: ['Beyond', '汪峰', '崔健', '许巍', '逃跑计划', '五月天', '痛仰乐队', '二手玫瑰', '黑豹乐队', '唐朝乐队', '零点乐队', '新裤子'],
    albums: ['摇滚经典', '光辉岁月', '怒放的生命', '摇滚现场', '金属风暴']
  },
  '日韩': {
    titles: ['First Love', '残酷天使的行动纲领', '樱花', '心の的条件', '青日', '秘密基地', '言叶',
      'Little Busters', 'Butterfly', '虹', '明日への扉', '君の知らない物語', '紅蓮華', 'Lemon',
      'Maru Maru Mori Mori', 'Gurenge', '中国的恢复', '阿里郎', '江南Style', 'Gentleman',
      'Psycho', 'Mr.Taxi', 'Nobody', 'Sorry Sorry', 'Super Clap', 'Bang Bang Bang', 'Fantastic Baby',
      'DNA', 'Blood Sweat & Tears', 'Spring Day', 'Dynamite', 'Butter', 'Permission to Dance',
      '偶像', '星光', '花火', '夏影', '秋意浓', '冬日恋歌', '雪花'],
    artists: ['宇多田光', '高桥洋子', '中岛美嘉', '滨崎步', '嵐', '乃木坂46', 'YOASOBI', '米津玄师',
      'PSY', '少女时代', 'Super Junior', 'BIGBANG', 'BTS', 'BLACKPINK', 'TWICE', 'EXO'],
    albums: ['J-POP精选', '日系经典', 'K-POP热歌', '韩流风暴', '亚洲流行']
  },
  '欧美': {
    titles: ['Imagine', 'Yesterday', 'Bohemian Rhapsody', 'Shape of You', 'Despacito', 'See You Again',
      'Rolling in the Deep', 'Hello', 'Someone Like You', 'Bad Romance', 'Poker Face', 'Billie Jean',
      'Like a Rolling Stone', 'Hey Jude', 'Let It Be', 'Hotel California', 'Stairway to Heaven',
      'Sweet Child O Mine', 'Smells Like Teen Spirit', 'Wonder Wall', 'Yellow', 'Viva La Vida',
      'Locked Out of Heaven', 'Uptown Funk', 'Thinking Out Loud', 'Blank Space', 'Bad Blood',
      'Work', 'One Dance', 'HUMBLE', 'God’s Plan', 'Sunflower', 'Dance The Night', 'Espresso',
      'As It Was', 'Anti-Hero', 'Flowers', 'Kill Bill', 'Cruel Summer', 'Blank Space'],
    artists: ['The Beatles', 'Queen', 'Ed Sheeran', 'Adele', 'Lady Gaga', 'Michael Jackson', 'Eagles',
      'Coldplay', 'Oasis', 'Guns N’ Roses', 'Bruno Mars', 'Taylor Swift', 'Drake', 'Justin Bieber', 'Dua Lipa'],
    albums: ['Western Classics', 'Pop Hits', 'Rock Legends', 'Billboard Top', 'Global Hits']
  },
  '纯音乐': {
    titles: ['卡农', '天空之城', '千与千寻', '神秘园之歌', '班得瑞', '月光', '爱的纪念', '水边的阿狄丽娜',
      'River Flows in You', 'Kiss The Rain', 'The Truth That You Leave', '风居住的街道', '远方的寂静',
      '天空之城', '菊次郎的夏天', 'Summer', 'Merry Christmas Mr. Lawrence', 'Glorious Day',
      'A Thousand Years', 'Experience', 'Titanic', 'My Heart Will Go On', '大鱼海棠', '琵琶语',
      '高山流水', '阳春白雪', '渔舟唱晚', '平湖秋月', '春江花月夜', '二泉映月', '梅花三弄',
      '卡农变奏曲', '夜的钢琴曲', '雨后', '星空', '宁静', '晨光', '海浪', '微风', '森林', '雨声'],
    artists: ['班得瑞', '理查德·克莱德曼', 'Yiruma', '石进', '久石让', 'S.E.N.S', '神秘园', '林海', 'Markus Brunnermeier'],
    albums: ['纯音乐精选', '轻音乐', '钢琴曲', '治愈系', '冥想音乐']
  },
  '古风': {
    titles: ['牵丝戏', '赤伶', '半壶纱', '烟雨行舟', '西游', '故宫的雪', '东风志', '不染', '易燃易爆炸',
      '叙世', '烟雨红尘', '花自飘零', '墨色江南', '长歌行', '兰亭序', '落在生命里的光', '似水流年',
      '归去来', '饮酒', '听风吟', '素心', '旧梦一场', '三生三世', '美人鱼', '春庭雪', '辞九门回忆',
      '半壶纱', '牵丝戏', '赤伶', '风筝误', '传统', '扬琴', '古琴', '琵琶', '竹笛', '埙', '鼓韵', '编钟', '雅乐'],
    artists: ['银临', '阿YueYue', '刘柯', '等什么君', 'MC阿哲', '许嵩', '河图', '音频怪物', '董贞', '心然'],
    albums: ['古风精选', '国风雅集', '江湖夜雨', '汉唐遗韵', '弦歌']
  },
  '游戏BGM': {
    titles: ['王者峡谷', '英雄联盟', '原神·风与歌', '吃鸡战场', '梦幻西游', '剑网三', '魔兽世界', '最终幻想',
      '塞尔达传说', '超级玛丽', '魂斗罗', '红色警戒', 'CS反恐精英', 'DNF地下城', '阴阳师', '明日方舟',
      '崩坏3', '碧蓝航线', '公主连结', 'FGO', '和平精英', ' quintet', 'Tetris Theme', 'Puzzle',
      '八位机', '像素世界', '像素冒险', '街机厅', '红白机', '怀旧游戏', 'Boss战', '胜利时刻',
      '冒险启程', '神秘遗迹', '森林探险', '冰原决战', '星空远征', '最终关卡', '隐藏关卡', '通关胜利'],
    artists: ['游戏音乐', '暴雪娱乐', '米哈游', '拳头游戏', '任天堂', 'SE', '腾讯游戏', '网易游戏'],
    albums: ['游戏原声带', '游戏BGM精选', '经典游戏音乐', '电竞音乐', '像素音乐']
  },
  '广场舞': {
    titles: ['最炫民族风', '小苹果', '广场舞大妈', '荷塘月色', '红尘情歌', '映山红', '月亮之上',
      '自由飞翔', '相亲相爱', '全家福', '健康舞起来', '快乐广场', '舞动中国', '活力节拍',
      '健康是福', '好日子', '红太阳', '欢聚一堂', '祖国好', '大美中国', '舞出好身材', '开心舞步',
      '快乐人生', '夕阳红', '舞动人生', '秧歌舞', '腰鼓舞', '扇子舞', '水兵舞', '恰恰舞',
      '伦巴舞', '桑巴舞', '探戈舞', '爵士舞', '肚皮舞', '拉丁舞', '健身舞', '晨练舞', '广场舞串烧', '民族团结'],
    artists: ['凤凰传奇', '筷子兄弟', '广场舞达人', '乌兰图雅', '李玲玉', '老猫', '音乐人合力'],
    albums: ['广场舞精选', '健身舞曲', '中老年舞曲', '广场舞串烧', '快乐舞步']
  }
}

const ARTIST_SUFFIX = ['', ' (Live)', ' (Remix)', ' (伴奏)', ' (DJ版)', ' (无损)']

/* ------------------------------------------------------------------ */
/* 生成歌曲                                                            */
/* ------------------------------------------------------------------ */
let songId = 1
let lyricId = 1
const songs = []
const lyrics = {}

const LYRIC_TEMPLATES = [
  ['夜色铺开一条长长的河', '我把心事折成纸船', '让它顺着旋律漂远', '副歌升起的时候', '整座城市都亮了起来',
    '间奏像雨后的风', '轻轻推开窗', '尾声慢慢落下来', '留在你耳边的温度'],
  ['风从远方吹来', '带着熟悉的气味', '走过四季的站台', '我在原地等待', '月光洒满了窗台',
    '回忆像潮水涌来', '那些年少的期待', '都变成现在的感慨', '愿你被世界温柔以待'],
  ['城市的霓虹闪烁', '人群里独自掠过', '耳机里的旋律', '是我唯一的寄托', '节奏撞击着脉搏',
    '烦恼都被抛在脑后', '跟着音乐一起跳动', '今夜不醉不罢休', '快乐其实很简单'],
  ['山路蜿蜒向远方', '云在山谷间飘荡', '炊烟升起的地方', '是我思念的故乡', '老屋门前的桂花',
    '还在 annually 开放', '外婆唱过的歌谣', '在耳畔轻轻回响', '那是回家的方向'],
  ['琴键落下的瞬间', '故事开始了新一页', '每一个音符都是', '写给你的明信片', '低音诉说眷恋',
    '高音点亮了黑夜', '旋律穿过时间的缝隙', '把回忆轻轻叠', '停在你我相遇那一页']
]

function makeLrc(title, artist, tpl, duration) {
  const start = between(5, 15)
  const step = Math.max(4, Math.floor((duration - start - 10) / (tpl.length + 2)))
  const lines = [`[00:00.00]${title} - ${artist}`, `[00:02.00]作词 : ${artist}`, `[00:04.00]作曲 : ${artist}`]
  tpl.forEach((line, i) => {
    const sec = start + i * step
    const mm = String(Math.floor(sec / 60)).padStart(2, '0')
    const ss = String(sec % 60).padStart(2, '0')
    lines.push(`[${mm}:${ss}.00]${line}`)
  })
  return lines.join('\n')
}

for (const [category, cfg] of Object.entries(SONG_SEED)) {
  // 每个分类扩展为约 50 首（基础标题 + 少量演绎版本）
  const base = cfg.titles.slice(0, 42)
  const variants = ['', ' (Live)', ' (Remix)', ' ( DJ版)']
  let n = 0
  for (let round = 0; round < 2 && n < 52; round++) {
    for (const title of base) {
      if (n >= 52) break
      const suffix = round === 0 ? '' : pick(variants.slice(1))
      const artist = pick(cfg.artists)
      const album = pick(cfg.albums)
      const dur = between(150, 320)
      const id = songId++
      const tpl = pick(LYRIC_TEMPLATES)
      const lrc = makeLrc(title + suffix, artist, tpl, dur)
      lyrics[id] = { id: lyricId++, songId: id, content: lrc, lines: tpl }
      songs.push({
        id,
        title: title + suffix,
        artist,
        album,
        category,
        src: AUDIO_POOL[id % AUDIO_POOL.length],
        cover: coverGradient(id),
        duration: dur,
        quality: pick(['SQ', 'HQ', '标准', 'HQ']),
        year: between(1998, 2026),
        playCount: between(1000, 9800000),
        tags: [category, pick(['热门', '经典', '新歌', '治愈', '燃', '必听'])]
      })
      n++
    }
  }
}

/* ------------------------------------------------------------------ */
/* 生成伴奏                                                            */
/* ------------------------------------------------------------------ */
const accompaniments = []
let accId = 1
for (let i = 0; i < 320; i++) {
  const src = songs[(i * 7 + 3) % songs.length]
  accompaniments.push({
    id: accId++,
    title: src.title.replace(/\s*\(.*?\)/g, '') + ' (伴奏)',
    originalSongId: src.id,
    artist: src.artist,
    category: src.category,
    src: src.src,
    cover: src.cover,
    duration: src.duration,
    bpm: between(60, 160),
    key: pick(['C', 'D', 'E', 'F', 'G', 'A', 'B', 'Am', 'Em', 'Dm', 'Gm']),
    quality: pick(['无损伴奏', '高品质伴奏', '标准伴奏']),
    hasGuideVocal: rnd() > 0.5,
    playCount: between(500, 1200000)
  })
}

/* ------------------------------------------------------------------ */
/* 生成有声专区                                                        */
/* ------------------------------------------------------------------ */
const AUDIO_ZONE = {
  '有声小说': {
    titles: ['斗破苍穹', '遮天', '完美世界', '诡秘之主', '庆余年', '雪中悍刀行', '赘婿', '扫墓人',
      '盗墓笔记', '鬼吹灯', '全职高手', '大主宰', '武动乾坤', '叶罗丽', '三体', '基地', '沙丘',
      '千年纪','全球高武', '修真聊天群', '一世之尊', '飞剑问道', '圣墟', '牧神记', '不败战神'],
    hosts: ['有声的紫襟', '头陀渊', '猫腻', '马正阳', '商虹', '张震', '玄子'],
    desc: '演播有声小说'
  },
  '广播剧': {
    titles: ['魔道祖师', '天官赐福', '山河表里', '撒野', '默读', '破云', '吞海', 'residency',
      '时光代理人', '光与夜之恋', '恋与制作人', '未定事件簿', ' Irene', '剑网三', '超越'],
    hosts: ['广播剧社', '声创联盟', '北斗企鹅', '729声工场', '光合积木'],
    desc: '精品广播剧'
  },
  '相声评书': {
    titles: ['郭德纲相声合集', '于谦 settles', '岳云鹏相声', '孙越相声', '单田芳评书', '田连元评书',
      '连丽如评书', '刘兰芳评书', '袁阔成评书', '评书三国演义', '评书水浒传', '评书隋唐演义',
      '评书岳飞传', '评书三侠五义', '评书白眉大侠', '相声茶馆', '德云社', '相声新势力'],
    hosts: ['郭德纲', '于谦', '岳云鹏', '单田芳', '田连元', '刘兰芳', '袁阔成'],
    desc: '传统曲艺'
  },
  '脱口秀': {
    titles: ['吐槽大会', '脱口秀大会', '喜剧大赛', '奇葩说', '王自健脱口秀', '李诞脱口秀',
      '呼兰脱口秀', '徐志胜脱口秀', '何广智脱口秀', '庞博脱口秀', '周奇墨脱口秀',
      '单口喜剧', '开放麦', '喜剧现场', '段子手', '幽默大师', '搞笑合集', '每日一笑'],
    hosts: ['李诞', '王自健', '呼兰', '徐志胜', '何广智', '庞博', '周奇墨'],
    desc: '爆笑脱口秀'
  },
  '儿童故事': {
    titles: ['格林童话', '安徒生童话', '一千零一夜', '西游记儿童版', '三国演义儿童版',
      '三字经', '弟子规', '唐诗三百首', '成语故事', '寓言故事', '睡前故事', '动物故事',
      '恐龙世界', '太空探险', '海洋奇遇', '森林音乐会', '小红帽', '灰姑娘', '白雪公主', '丑小鸭'],
    hosts: ['松鼠妈妈', '彩虹姐姐', '小明哥哥', '月亮阿姨', '故事大王'],
    desc: '陪伴成长'
  },
  '人文科普': {
    titles: ['十万个为什么', '时间的故事', '宇宙的诞生', '地球的秘密', '人类简史', '全球通史',
      '博物馆之夜', '故宫博物院', '敦煌莫高窟', '中国通史', '世界Uncivilization', '物理学的进化',
      '天文望远镜', '量子力学入门', '人工智能简史', '心理学与生活', '经济学原理', '哲学的故事',
      '艺术史', '音乐史话', '建筑之美', '文学经典', '历史那些事', '科学声音', '博物大百科'],
    hosts: ['樊登', '罗翔', '得到', '喜马拉雅', '知识星球', '科学声音'],
    desc: '涨知识'
  },
  '电台': {
    titles: ['深夜电台', '城市之声', '午夜旋律', '音乐现场', '情感电台', '夜听', '一米阳光',
      'FM调频', 'FM青春', '城市晚高峰', '早间新闻', '财经之声', '交通广播', '音乐榜单',
      '新歌推荐', '经典回放', '听众点歌', '心情日记', '故事电台', '晚安电台'],
    hosts: ['DJ小河', 'DJ阿哲', 'DJ小雅', 'FM103.9', 'FM91.5', '音乐台', '都市之声'],
    desc: '声音陪伴'
  },
  '白噪音': {
    titles: ['雨声', '雷声', '海浪声', '溪流声', '森林鸟鸣', '夜晚虫鸣', '壁炉声', '风雪声',
      '咖啡馆', '火车声', '飞机舱内', '办公室', '图书馆', '微风拂过', '篝火', '瀑布',
      '下雨天', '暴雨', '小雨', '雷雨交加', '竹林', '海边', '山间', '清晨', '午夜', '深度睡眠',
      '专注工作', '冥想放松', '婴儿安睡', '治愈系', '自然之声', '城市夜景', '帐篷露营', '雨打芭蕉'],
    hosts: ['自然之声', '白噪音研究所', '睡眠研究所', '冥想空间'],
    desc: '助眠放松'
  },
  'FM收音机': {
    titles: ['中央人民广播电台', '中国之声', '经济之声', '音乐之声', '交通之声', '文艺之声',
      '都市之声', '新闻广播', '音乐广播', '交通广播', '戏曲广播', '小说广播', '少儿广播',
      '健康之声', '旅游之声', '城市FM', '校园FM', '网络电台', '国际在线', '环球资讯', '英语广播'],
    hosts: ['FM101.1', 'FM103.9', 'FM91.5', 'FM105.8', '中央广播电视总台', '地方电台'],
    desc: '实时收音'
  }
}

const audioZone = []
let azId = 1
for (const [category, cfg] of Object.entries(AUDIO_ZONE)) {
  const count = category === '白噪音' ? 36 : 28
  for (let i = 0; i < count; i++) {
    const title = cfg.titles[i % cfg.titles.length] + (i >= cfg.titles.length ? ` ${Math.floor(i / cfg.titles.length) + 1}` : '')
    const dur = between(600, 7200)
    audioZone.push({
      id: azId++,
      title,
      category,
      host: pick(cfg.hosts),
      desc: cfg.desc,
      src: AUDIO_POOL[azId % AUDIO_POOL.length],
      cover: coverGradient(azId + 3),
      duration: dur,
      episodes: between(1, 120),
      playCount: between(1000, 5600000),
      tags: [category, pick(['热门', '完结', '更新中', '精品'])]
    })
  }
}

/* ------------------------------------------------------------------ */
/* 歌单 / 榜单 / 音效预设                                              */
/* ------------------------------------------------------------------ */
const playlists = [
  { id: 1, name: '华语经典 · 值得一听再听', category: '华语', cover: coverGradient(1), description: '那些年循环过的新歌与经典', tags: ['华语', '经典'] },
  { id: 2, name: '抖音热歌榜 · 全网都在听', category: '流行', cover: coverGradient(2), description: '当下最火的流行金曲', tags: ['流行', '热歌'] },
  { id: 3, name: '深夜 DJ · 节奏不停', category: 'DJ', cover: coverGradient(3), description: '重低音嗨曲，车载必备', tags: ['DJ', '电音'] },
  { id: 4, name: '怀旧金曲 · 岁月留声', category: '老歌', cover: coverGradient(4), description: '听了几十年的老歌', tags: ['老歌', '怀旧'] },
  { id: 5, name: '民谣在路上 · 诗和远方', category: '民谣', cover: coverGradient(5), description: '一把吉他，一个故事', tags: ['民谣', '治愈'] },
  { id: 6, name: '摇滚不死 · 热血不息', category: '摇滚', cover: coverGradient(6), description: '经典摇滚与金属', tags: ['摇滚', '经典'] },
  { id: 7, name: '日韩风 · 亚洲潮流', category: '日韩', cover: coverGradient(7), description: 'J-POP & K-POP 精选', tags: ['日韩', '流行'] },
  { id: 8, name: '欧美经典 · 全球金曲', category: '欧美', cover: coverGradient(8), description: 'Billboard 常客', tags: ['欧美', '经典'] },
  { id: 9, name: '纯音乐 · 治愈时刻', category: '纯音乐', cover: coverGradient(9), description: '安静地听一会儿', tags: ['纯音乐', '轻音乐'] },
  { id: 10, name: '古风雅韵 · 中国风', category: '古风', cover: coverGradient(10), description: '一曲梦回千年', tags: ['古风', '国风'] },
  { id: 11, name: '游戏 BGM · 燃到起飞', category: '游戏BGM', cover: coverGradient(11), description: '那些让人热血沸腾的旋律', tags: ['游戏', 'BGM'] },
  { id: 12, name: '广场舞 · 快乐舞起来', category: '广场舞', cover: coverGradient(12), description: '音乐一响，脚步就动', tags: ['广场舞', '健身'] },
  { id: 13, name: 'K歌伴奏 · 海量曲库', category: '伴奏', cover: coverGradient(13), description: '随时随地想唱就唱', tags: ['伴奏', 'K歌'] },
  { id: 14, name: '睡前故事 · 晚安宝贝', category: '有声', cover: coverGradient(14), description: '陪孩子进入梦乡', tags: ['儿童', '故事'] },
  { id: 15, name: '白噪音 · 深度睡眠', category: '有声', cover: coverGradient(15), description: '隔绝喧嚣，安静入睡', tags: ['白噪音', '助眠'] }
]

const effects = [
  { id: 'viper', name: '蝰蛇音效', icon: '🐍', desc: '招牌调音方案', params: { 低音: 65, 中音: 50, 高音: 55, 环绕: 40 } },
  { id: 'surround', name: '全景声', icon: '🌐', desc: '沉浸式 360° 声场', params: { 声场宽度: 85, 环绕强度: 70, 混响: 40 } },
  { id: 'bass', name: '超重低音', icon: '🔊', desc: '动感重低音增强', params: { 低音: 95, 中音: 45, 高音: 40, 低音增强: 80 } },
  { id: '3d', name: '3D 环绕', icon: '🎧', desc: '立体声空间环绕', params: { 环绕强度: 90, 声场宽度: 75, 头部追踪: 60 } },
  { id: 'pop', name: '流行', icon: '🎵', desc: '人声清晰，适合流行', params: { 低音: 55, 中音: 65, 高音: 60 } },
  { id: 'rock', name: '摇滚', icon: '🎸', desc: '强劲有力的摇滚现场', params: { 低音: 80, 中音: 55, 高音: 75, 失真: 35 } },
  { id: 'classical', name: '古典', icon: '🎻', desc: '还原音乐厅现场', params: { 混响: 80, 声场宽度: 90, 低音: 45, 高音: 60 } },
  { id: 'vocal', name: '人声', icon: '🎤', desc: '突出人声细节', params: { 中音: 85, 高音: 65, 低音: 35, 降噪: 50 } },
  { id: 'jazz', name: '爵士', icon: '🎷', desc: '温暖慵懒的爵士味', params: { 低音: 60, 中音: 60, 高音: 55, 混响: 45 } },
  { id: 'electronic', name: '电音', icon: '⚡', desc: '电子音乐增强', params: { 低音: 85, 中音: 50, 高音: 85, 节奏: 80 } },
  { id: 'night', name: '夜晚', icon: '🌙', desc: '夜间柔和听感', params: { 低音: 40, 中音: 55, 高音: 45, 音量: 60 } },
  { id: 'original', name: '原声', icon: '🔊', desc: '关闭所有音效', params: { 低音: 50, 中音: 50, 高音: 50 } }
]

const charts = {
  hot: songs.slice().sort((a, b) => b.playCount - a.playCount).slice(0, 100).map((s) => s.id),
  rising: songs.slice().sort((a, b) => (b.playCount % 99991) - (a.playCount % 99991)).slice(0, 100).map((s) => s.id),
  new: songs.slice().sort((a, b) => b.year - a.year).slice(0, 100).map((s) => s.id),
  original: songs.filter((s) => !s.title.includes('Remix') && !s.title.includes('DJ')).slice(0, 100).map((s) => s.id)
}

/* ------------------------------------------------------------------ */
/* 写出                                                                */
/* ------------------------------------------------------------------ */
const catalog = {
  version: '1.0.0',
  generatedAt: new Date().toISOString(),
  categories: Object.keys(SONG_SEED),
  songs,
  lyrics,
  accompaniments,
  audioZoneCategories: Object.keys(AUDIO_ZONE),
  audioZone,
  playlists,
  effects,
  charts
}

fs.mkdirSync(DATA_DIR, { recursive: true })
const target = path.join(DATA_DIR, 'catalog.json')
fs.writeFileSync(target, JSON.stringify(catalog), 'utf8')

console.log('种子数据已生成:', target)
console.log('歌曲:', songs.length, '歌词:', Object.keys(lyrics).length, '伴奏:', accompaniments.length,
  '有声内容:', audioZone.length, '歌单:', playlists.length, '音效:', effects.length)
