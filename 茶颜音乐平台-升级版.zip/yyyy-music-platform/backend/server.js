/**
 * 音乐平台后端服务（零第三方依赖，Node.js 18+）
 *
 * 启动: node server.js        默认监听 8080，与前端 vite 代理一致
 * 响应统一格式: { code: 200, msg: 'ok', data: ... }
 *
 * 接口分组：
 *  - 系统/用户/收藏/资料/播放次数    （兼容原前端契约）
 *  - 歌曲/分类/榜单/搜索/AI推荐/歌词
 *  - 伴奏/录歌/修音
 *  - 有声专区
 *  - 听歌识曲 / 本地扫描
 *  - 音效 / 播放器设置 / 定时关闭 / 播放历史 / 自建歌单
 */
import http from 'node:http'
import crypto from 'node:crypto'
import * as db from './lib/db.js'
import * as localMusic from './lib/local-music.js'
import * as jamendo from './lib/jamendo.js'

const PORT = Number(process.env.PORT || 8080)

/* ================================================================== */
/* 基础工具                                                            */
/* ================================================================== */
function send(res, body, status = 200) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-User-Id',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
  })
  res.end(JSON.stringify(body))
}
const ok = (res, data, msg = 'ok') => send(res, { code: 200, msg, data })
const fail = (res, msg, code = 400, status = 200) => send(res, { code, msg, data: null }, status)

function readBody(req) {
  return new Promise((resolve) => {
    let raw = ''
    req.on('data', (c) => { raw += c })
    req.on('end', () => {
      if (!raw) return resolve({})
      try { resolve(JSON.parse(raw)) } catch (e) { resolve({}) }
    })
  })
}

const routes = []
function route(method, pattern, handler) {
  const keys = []
  const source = pattern.replace(/:[A-Za-z_]\w*/g, (m) => {
    keys.push(m.slice(1))
    return '([^/]+)'
  })
  routes.push({ method, regex: new RegExp('^' + source + '$'), keys, handler })
}

function paginate(arr, q) {
  const page = Math.max(1, Number(q.get('page')) || 1)
  const size = Math.min(200, Math.max(1, Number(q.get('size')) || 50))
  const total = arr.length
  return { list: arr.slice((page - 1) * size, page * size), total, page, size, pages: Math.ceil(total / size) }
}
const hasPaging = (q) => ['page', 'size', 'category', 'sort', 'paged'].some((k) => q.has(k))
const shuffle = (arr) => {
  const a = arr.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}
const matchText = (haystack, q) => String(haystack || '').toLowerCase().includes(String(q || '').toLowerCase())

function findUser(req) {
  const id = req.headers['x-user-id']
  if (id == null) return null
  return db.getUsers().find((u) => u.id === Number(id)) || null
}
function requireUser(req, res) {
  const u = findUser(req)
  if (!u) fail(res, '请先登录', 401)
  return u
}

/**
 * 统一解析歌曲 ID → 可播放的歌曲对象。
 * 支持三种来源：内置数字 ID、local-<hash> 本地音乐、jam-<id> Jamendo。
 * 返回对象带 sourceType，前端据此还原播放地址。
 */
async function resolveTrack(rawId) {
  const id = String(rawId ?? '')
  if (id.startsWith('local-')) {
    const t = await localMusic.getLocalTrack(db.getPool(), id.slice(6))
    if (!t) return null
    return {
      id, title: t.title || t.name, artist: t.artist || '未知', album: t.album || '',
      src: '/api/local/stream/' + encodeURIComponent(t.id), cover: t.cover || '',
      duration: t.size ? 0 : 0, dur: 0, sourceType: 'local'
    }
  }
  if (id.startsWith('jam-')) {
    const t = await jamendo.getJamendoTrack(db.getPool(), id.slice(4))
    if (!t) return null
    return {
      id, title: t.title, artist: t.artist, album: t.album || '',
      src: t.audio || '', cover: t.image || '', duration: t.duration || 0,
      sourceType: 'jamendo'
    }
  }
  return db.songById(Number(id)) || null
}

/* ================================================================== */
/* 系统                                                                */
/* ================================================================== */
route('GET', '/api/health', (ctx) => ok(ctx.res, {
  status: 'ok', version: '1.0.0', time: new Date().toISOString(),
  counts: {
    songs: db.catalog.songs.length,
    accompaniments: db.catalog.accompaniments.length,
    audioZone: db.catalog.audioZone.length,
    lyrics: Object.keys(db.catalog.lyrics).length,
    playlists: db.catalog.playlists.length,
    effects: db.catalog.effects.length
  }
}))

/* ================================================================== */
/* 用户                                                                */
/* ================================================================== */
route('GET', '/api/user/exists', ({ q, res }) => {
  const username = String(q.get('username') || '').trim().toLowerCase()
  ok(res, db.getUsers().some((u) => u.username.toLowerCase() === username))
})

route('POST', '/api/user/register', async ({ body, res }) => {
  const username = String(body.username || '').trim()
  const phone = String(body.phone || '').trim()
  const password = String(body.password || '')
  if (!username) return fail(res, '请输入用户名')
  if (username.length < 2 || username.length > 30) return fail(res, '用户名长度需为 2-30 位')
  if (password.length < 6) return fail(res, '密码至少 6 位')
  if (db.getUsers().some((u) => u.username.toLowerCase() === username.toLowerCase())) return fail(res, '该用户名已被注册')

  const user = {
    id: db.nextUserId(), username, phone, password: db.hashPassword(password),
    nickname: username, signature: '这个人很懒，什么都没写',
    gender: 'secret', birthday: '', city: '', email: '', avatar: 'a1', background: '',
    playCount: 0, role: 'user', createdAt: new Date().toISOString()
  }
  const users = db.getUsers().concat(user)
  db.setUsers(users)
  const ud = db.getUserData()
  ud.favorites[user.id] = []
  ud.history[user.id] = []
  db.setUserData(ud)
  ok(res, { username: user.username, id: user.id }, '注册成功')
})

route('POST', '/api/user/login', async ({ body, res }) => {
  const username = String(body.username || '').trim()
  const password = String(body.password || '')
  const user = db.getUsers().find((u) => u.username.toLowerCase() === username.toLowerCase())
  if (!user) return fail(res, '该账号不存在，请先注册')
  if (!db.verifyPassword(password, user.password)) return fail(res, '密码错误，请重新输入')
  ok(res, db.publicUser(user), '登录成功')
})

route('GET', '/api/user/:id', ({ params, res }) => {
  const u = db.getUsers().find((x) => x.id === Number(params.id))
  if (!u) return fail(res, '用户不存在', 404)
  ok(res, db.publicUser(u))
})

route('PUT', '/api/user/profile', async ({ req, body, res }) => {
  const u = requireUser(req, res)
  if (!u) return
  const allowed = ['nickname', 'gender', 'birthday', 'city', 'email', 'signature', 'avatar', 'background']
  const users = db.getUsers()
  const target = users.find((x) => x.id === u.id)
  for (const k of allowed) if (body[k] !== undefined) target[k] = body[k]
  db.setUsers(users)
  ok(res, db.publicUser(target), '资料已保存')
})

route('POST', '/api/user/:id/play', ({ params, res }) => {
  const users = db.getUsers()
  const u = users.find((x) => x.id === Number(params.id))
  if (!u) return fail(res, '用户不存在', 404)
  u.playCount = (Number(u.playCount) || 0) + 1
  db.setUsers(users)
  ok(res, { playCount: u.playCount })
})

/* ================================================================== */
/* 歌曲 / 分类 / 榜单 / 推荐 / 歌词                                    */
/* ================================================================== */
route('GET', '/api/song/list', ({ q, res }) => {
  let list = db.catalog.songs.slice()
  const keyword = q.get('keyword') || q.get('q') || ''
  const category = q.get('category') || ''
  const sort = q.get('sort') || ''
  if (keyword) {
    list = list.filter((s) => matchText(`${s.title} ${s.artist} ${s.album} ${s.category}`, keyword))
  }
  if (category && category !== '全部') list = list.filter((s) => s.category === category)
  if (sort === 'hot') list.sort((a, b) => b.playCount - a.playCount)
  if (sort === 'new') list.sort((a, b) => b.year - a.year)
  if (sort === 'random') list = shuffle(list)
  // 兼容原前端：无分页参数时直接返回数组
  if (!hasPaging(q)) return ok(res, list)
  ok(res, paginate(list, q))
})

route('GET', '/api/song/:id', async ({ params, res }) => {
  const s = await resolveTrack(params.id)
  if (!s) return fail(res, '歌曲不存在', 404)
  ok(res, s)
})

route('GET', '/api/song/:id/lyric', ({ params, res }) => {
  const song = db.songById(params.id)
  if (!song) return fail(res, '歌曲不存在', 404)
  const item = db.lyricBySongId(song.id) || Object.values(db.catalog.lyrics)[0]
  const lines = item?.content.split('\n').filter((x) => x.includes(']')).map((x) => x.slice(x.indexOf(']') + 1))
  ok(res, lines && lines.length ? lines : ['暂无歌词'])
})

route('GET', '/api/song/:id/lrc', ({ params, res }) => {
  const song = db.songById(params.id)
  if (!song) return fail(res, '歌曲不存在', 404)
  const item = db.lyricBySongId(song.id)
  ok(res, { lrc: item?.content || '[00:00.00]暂无歌词', lines: item?.lines || [] })
})

route('GET', '/api/categories', ({ res }) => {
  const list = db.catalog.categories.map((name, i) => ({
    name,
    count: db.catalog.songs.filter((s) => s.category === name).length,
    cover: `linear-gradient(135deg,${['#1ec8ff,#7b5cff', '#ff8a5b,#ff5b8a', '#22d3a6,#1e8bff', '#f6c453,#ff7e5f', '#a06bff,#ff6bcb', '#3ad1ff,#2e6cff', '#ff5b8a,#ffb15b', '#5be0a0,#1ec8ff', '#ff7e5f,#a06bff', '#4facfe,#00f2fe', '#f7971e,#ffd200', '#43e97b,#38f9d7'][i % 12]})`,
    icon: ['🎤', '🔥', '🎧', '📻', '🎸', '🥁', '🌸', '🌍', '🎹', '🏮', '🎮', '💃'][i % 12]
  }))
  ok(res, list)
})

route('GET', '/api/charts', ({ q, res }) => {
  const type = q.get('type') || 'hot'
  const ids = db.catalog.charts[type] || db.catalog.charts.hot || []
  let list = ids.map(db.songById).filter(Boolean)
  const limit = Number(q.get('limit')) || 100
  ok(res, list.slice(0, limit))
})

route('GET', '/api/recommend', ({ q, req, res }) => {
  const user = findUser(req)
  const uid = q.get('userId') || user?.id
  const limit = Math.min(200, Number(q.get('limit')) || 50)
  const ud = db.getUserData()
  const favIds = uid != null ? (ud.favorites[uid] || []) : []
  const hist = uid != null ? (ud.history[uid] || []) : []
  const source = [...favIds, ...hist.map((h) => h.songId)].filter(Boolean)

  let cats = []
  if (source.length) {
    const counter = {}
    source.forEach((id) => {
      const s = db.songById(id)
      if (s) counter[s.category] = (counter[s.category] || 0) + 1
    })
    cats = Object.entries(counter).sort((a, b) => b[1] - a[1]).map(([c]) => c)
  }
  if (!cats.length) cats = db.catalog.categories.slice()

  const liked = new Set(favIds)
  const pool = db.catalog.songs.filter((s) => cats.includes(s.category) && !liked.has(s.id))
  const fallback = db.catalog.songs.filter((s) => !liked.has(s.id))

  // 混合：偏好分类高分歌曲 + 全局热门 + 随机探索
  const preferred = pool.slice().sort((a, b) => b.playCount - a.playCount).slice(0, Math.ceil(limit * 0.6))
  const hot = fallback.slice().sort((a, b) => b.playCount - a.playCount).slice(0, Math.ceil(limit * 0.25))
  const explore = shuffle(fallback).slice(0, limit)
  const seen = new Set()
  const out = []
  for (const s of [...preferred, ...hot, ...explore]) {
    if (!seen.has(s.id)) { seen.add(s.id); out.push(s) }
    if (out.length >= limit) break
  }
  ok(res, out.map((s) => ({ ...s, recommendReason: cats.includes(s.category) ? '根据你的收藏偏好推荐' : '大家都在听' })))
})

route('GET', '/api/search', ({ q, res }) => {
  const keyword = q.get('q') || q.get('keyword') || ''
  const type = q.get('type') || 'all'
  if (!keyword) return ok(res, { songs: [], accompaniments: [], audioZone: [] })
  const result = {
    songs: (type === 'all' || type === 'song')
      ? db.catalog.songs.filter((s) => matchText(`${s.title} ${s.artist} ${s.album} ${s.category}`, keyword)).slice(0, 100) : [],
    accompaniments: (type === 'all' || type === 'accompaniment')
      ? db.catalog.accompaniments.filter((a) => matchText(`${a.title} ${a.artist} ${a.category}`, keyword)).slice(0, 60) : [],
    audioZone: (type === 'all' || type === 'audio')
      ? db.catalog.audioZone.filter((a) => matchText(`${a.title} ${a.host} ${a.category}`, keyword)).slice(0, 60) : []
  }
  ok(res, result)
})

/* ================================================================== */
/* 收藏                                                                */
/* ================================================================== */
route('GET', '/api/favorite/:userId', ({ params, res }) => {
  const ud = db.getUserData()
  ok(res, ud.favorites[params.userId] || [])
})

route('POST', '/api/favorite/:userId/toggle', async ({ params, body, res }) => {
  const uid = params.userId
  const songId = String(body.songId ?? '')
  if (!await resolveTrack(songId)) return fail(res, '歌曲不存在', 404)
  const ud = db.getUserData()
  if (!ud.favorites[uid]) ud.favorites[uid] = []
  const idx = ud.favorites[uid].findIndex((x) => String(x) === songId)
  if (idx >= 0) ud.favorites[uid].splice(idx, 1)
  else ud.favorites[uid].push(songId)
  db.setUserData(ud)
  ok(res, { favorited: idx < 0 })
})

route('DELETE', '/api/favorite/:userId', ({ params, res }) => {
  const ud = db.getUserData()
  ud.favorites[params.userId] = []
  db.setUserData(ud)
  ok(res, { cleared: true })
})

/* ================================================================== */
/* 伴奏：曲库 / 录歌 / 修音                                            */
/* ================================================================== */
route('GET', '/api/accompaniment/categories', ({ res }) => {
  const cats = [...new Set(db.catalog.accompaniments.map((a) => a.category))]
  ok(res, cats.map((name) => ({
    name,
    count: db.catalog.accompaniments.filter((a) => a.category === name).length
  })))
})

route('GET', '/api/accompaniment/list', ({ q, res }) => {
  let list = db.catalog.accompaniments.slice()
  const keyword = q.get('keyword') || ''
  const category = q.get('category') || ''
  if (keyword) list = list.filter((a) => matchText(`${a.title} ${a.artist} ${a.category}`, keyword))
  if (category && category !== '全部') list = list.filter((a) => a.category === category)
  if (q.get('sort') === 'hot') list.sort((a, b) => b.playCount - a.playCount)
  ok(res, hasPaging(q) ? paginate(list, q) : list)
})

route('GET', '/api/accompaniment/:id', ({ params, res }) => {
  const a = db.accById(params.id)
  if (!a) return fail(res, '伴奏不存在', 404)
  ok(res, a)
})

route('POST', '/api/accompaniment/:id/record', async ({ params, req, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const acc = db.accById(params.id)
  if (!acc) return fail(res, '伴奏不存在', 404)
  const ud = db.getUserData()
  const rec = {
    id: db.nextId(ud.recordings),
    userId: user.id,
    accompanimentId: acc.id,
    title: acc.title.replace(' (伴奏)', ' (我的演唱)'),
    duration: Number(body.duration) || acc.duration,
    key: body.key || acc.key,
    pitch: Number(body.pitch) || 0,
    autoTune: body.autoTune !== false,
    strength: Number(body.strength) || 60,
    reverb: Number(body.reverb) || 30,
    createdAt: new Date().toISOString(),
    status: 'recorded'
  }
  ud.recordings.unshift(rec)
  db.setUserData(ud)
  ok(res, rec, '录歌完成')
})

route('GET', '/api/recording', ({ q, req, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  ok(res, ud.recordings.filter((r) => r.userId === user.id))
})

route('PUT', '/api/recording/:id', async ({ params, req, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const rec = ud.recordings.find((r) => r.id === Number(params.id) && r.userId === user.id)
  if (!rec) return fail(res, '录音不存在', 404)
  for (const k of ['pitch', 'autoTune', 'strength', 'reverb', 'key']) {
    if (body[k] !== undefined) rec[k] = body[k]
  }
  rec.status = 'tuned'
  rec.updatedAt = new Date().toISOString()
  db.setUserData(ud)
  ok(res, rec, '修音参数已保存')
})

/* ================================================================== */
/* 有声专区                                                            */
/* ================================================================== */
route('GET', '/api/audio-zone/categories', ({ res }) => {
  ok(res, db.catalog.audioZoneCategories.map((name, i) => ({
    name,
    count: db.catalog.audioZone.filter((a) => a.category === name).length,
    icon: ['📖', '🎭', '🎙️', '😂', '🧸', '📚', '📻', '🌙', '📡'][i % 9]
  })))
})

route('GET', '/api/audio-zone/list', ({ q, res }) => {
  let list = db.catalog.audioZone.slice()
  const keyword = q.get('keyword') || ''
  const category = q.get('category') || ''
  if (keyword) list = list.filter((a) => matchText(`${a.title} ${a.host} ${a.category} ${a.desc}`, keyword))
  if (category && category !== '全部') list = list.filter((a) => a.category === category)
  if (q.get('sort') === 'hot') list.sort((a, b) => b.playCount - a.playCount)
  ok(res, hasPaging(q) ? paginate(list, q) : list)
})

route('GET', '/api/audio-zone/:id', ({ params, res }) => {
  const a = db.azById(params.id)
  if (!a) return fail(res, '内容不存在', 404)
  ok(res, a)
})

/* ================================================================== */
/* 音效预设                                                            */
/* ================================================================== */
route('GET', '/api/effects', ({ res }) => ok(res, db.catalog.effects))
route('GET', '/api/effects/:id', ({ params, res }) => {
  const e = db.catalog.effects.find((x) => x.id === params.id)
  if (!e) return fail(res, '音效不存在', 404)
  ok(res, e)
})

/* ================================================================== */
/* 听歌识曲                                                            */
/* ================================================================== */
function recognizeScore(song, keyword) {
  let score = 0
  const q = String(keyword || '').toLowerCase().trim()
  if (!q) return 0
  const title = String(song.title || '').toLowerCase()
  const artist = String(song.artist || '').toLowerCase()
  const album = String(song.album || '').toLowerCase()
  if (title === q) score += 100
  if (title.includes(q)) score += 60
  else {
    // 逐字匹配（哼唱/错别字容错）
    const chars = q.replace(/[^\u4e00-\u9fa5a-z0-9]/g, '')
    let hit = 0
    for (const c of chars) if (title.includes(c) || artist.includes(c) || album.includes(c)) hit++
    score += Math.floor((hit / Math.max(1, chars.length)) * 45)
  }
  if (artist.includes(q)) score += 30
  if (album.includes(q)) score += 10
  return score
}

route('POST', '/api/recognize', async ({ body, req, res }) => {
  const hint = String(body.hint || body.filename || '').replace(/\.(mp3|wav|m4a|flac|aac)$/i, '').trim()
  const audio = body.audioBase64 || ''
  let result = []

  if (hint) {
    const scored = db.catalog.songs.map((s) => ({ s, score: recognizeScore(s, hint) }))
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
    result = scored.map((x) => ({
      song: x.s,
      confidence: Math.min(99, Math.round(50 + x.score / 2)),
      matchedBy: '哼唱/关键词识别'
    }))
  }

  // 纯音频指纹（演示版：根据长度与哈希从热门曲库中确定性匹配）
  if (!result.length && audio) {
    let hash = 0
    for (let i = 0; i < Math.min(audio.length, 4096); i += 16) hash = (hash * 31 + audio.charCodeAt(i)) >>> 0
    const pool = db.catalog.charts.hot.map(db.songById).filter(Boolean).slice(0, 100)
    const idx = hash % pool.length
    result = [0, 1, 2].map((d) => ({
      song: pool[(idx + d) % pool.length],
      confidence: 92 - d * 9,
      matchedBy: '音频指纹识别'
    }))
  }

  if (!result.length) {
    const fallback = shuffle(db.catalog.songs.filter((s) => s.playCount > 3000000)).slice(0, 3)
    result = fallback.map((s, i) => ({ song: s, confidence: 65 - i * 8, matchedBy: '相似旋律匹配' }))
  }

  const ud = db.getUserData()
  const user = findUser(req)
  ud.recognitionLog.unshift({
    id: crypto.randomUUID(), userId: user?.id || null, hint: hint || null,
    hasAudio: Boolean(audio), count: result.length, at: new Date().toISOString()
  })
  ud.recognitionLog = ud.recognitionLog.slice(0, 200)
  db.setUserData(ud)
  ok(res, result)
})

/* ================================================================== */
/* 歌单 / 历史 / 睡眠定时 / 播放器设置                                 */
/* ================================================================== */
route('GET', '/api/playlist', ({ q, req, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const mine = ud.playlists.filter((p) => p.userId === user.id)
  ok(res, { system: db.catalog.playlists, mine })
})

route('POST', '/api/playlist', async ({ req, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const name = String(body.name || '').trim()
  if (!name) return fail(res, '歌单名称不能为空')
  const ud = db.getUserData()
  const pl = {
    id: db.nextId(ud.playlists), userId: user.id, name,
    description: body.description || '', cover: `linear-gradient(135deg,#ff8a5b,#ff5b8a)`,
    songIds: [], createdAt: new Date().toISOString()
  }
  ud.playlists.unshift(pl)
  db.setUserData(ud)
  ok(res, pl, '歌单已创建')
})

route('DELETE', '/api/playlist/:id', ({ req, params, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const idx = ud.playlists.findIndex((p) => p.id === Number(params.id) && p.userId === user.id)
  if (idx < 0) return fail(res, '歌单不存在', 404)
  ud.playlists.splice(idx, 1)
  db.setUserData(ud)
  ok(res, { deleted: true })
})

route('POST', '/api/playlist/:id/songs', async ({ req, params, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const pl = ud.playlists.find((p) => p.id === Number(params.id) && p.userId === user.id)
  if (!pl) return fail(res, '歌单不存在', 404)
  const songId = Number(body.songId)
  if (!db.songById(songId)) return fail(res, '歌曲不存在', 404)
  const idx = pl.songIds.indexOf(songId)
  if (body.action === 'remove' || idx >= 0) {
    if (idx >= 0) pl.songIds.splice(idx, 1)
  } else pl.songIds.push(songId)
  db.setUserData(ud)
  ok(res, pl)
})

route('POST', '/api/history', async ({ req, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const songId = String(body.songId ?? '')
  if (!await resolveTrack(songId)) return fail(res, '歌曲不存在', 404)
  const ud = db.getUserData()
  if (!ud.history[user.id]) ud.history[user.id] = []
  ud.history[user.id] = ud.history[user.id].filter((h) => String(h.songId) !== songId)
  ud.history[user.id].unshift({ songId, at: new Date().toISOString() })
  ud.history[user.id] = ud.history[user.id].slice(0, 200)
  db.setUserData(ud)
  ok(res, { ok: true })
})

route('GET', '/api/history', async ({ q, req, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const rows = (ud.history[user.id] || []).slice(0, Number(q.get('limit')) || 100)
  const list = []
  for (const h of rows) {
    const song = await resolveTrack(h.songId)
    if (song) list.push({ ...song, playedAt: h.at })
  }
  ok(res, list)
})

route('POST', '/api/sleep-timer', async ({ req, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const minutes = Number(body.minutes) || 0
  if (minutes <= 0) {
    delete ud.sleepTimers[user.id]
    db.setUserData(ud)
    return ok(res, { enabled: false }, '定时关闭已取消')
  }
  ud.sleepTimers[user.id] = {
    minutes, enabled: true,
    triggerAt: new Date(Date.now() + minutes * 60000).toISOString(),
    mode: body.mode || 'current', at: new Date().toISOString()
  }
  db.setUserData(ud)
  ok(res, ud.sleepTimers[user.id], `${minutes} 分钟后关闭`)
})

route('GET', '/api/sleep-timer', ({ req, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  const t = ud.sleepTimers[user.id]
  if (!t) return ok(res, { enabled: false })
  const remain = Math.max(0, Math.round((new Date(t.triggerAt).getTime() - Date.now()) / 60000))
  ok(res, { ...t, remainingMinutes: remain, expired: remain <= 0 })
})

route('GET', '/api/settings/player', ({ req, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  ok(res, Object.assign({ speed: 1, lyricMode: 'rolling', effectId: 'original', volume: 0.7, quality: 'HQ' }, ud.playerSettings[user.id] || {}))
})

route('PUT', '/api/settings/player', async ({ req, body, res }) => {
  const user = requireUser(req, res)
  if (!user) return
  const ud = db.getUserData()
  ud.playerSettings[user.id] = Object.assign({}, ud.playerSettings[user.id] || {}, body)
  db.setUserData(ud)
  ok(res, ud.playerSettings[user.id], '播放器设置已保存')
})

/* ================================================================== */
/* 本地音乐库（真实文件扫描 + 流式播放）                               */
/* ================================================================== */
route('GET', '/api/local/roots', ({ res }) => ok(res, localMusic.getRoots()))
route('POST', '/api/local/roots', async ({ body, res }) => {
  const roots = Array.isArray(body.roots) ? body.roots : String(body.roots || '').split(';')
  const saved = localMusic.saveRoots(roots.map((r) => String(r).trim()).filter(Boolean))
  ok(res, saved, '文件夹路径已保存')
})
route('GET', '/api/local/tracks', async ({ q, res }) => {
  const pool = db.getPool()
  if (!pool) return fail(res, '数据库不可用', 503, 503)
  ok(res, await localMusic.listLocalTracks(pool, {
    keyword: q.get('keyword') || '', page: q.get('page') || 1, size: q.get('size') || 50
  }))
})
route('POST', '/api/local/scan', async ({ body, res }) => {
  const pool = db.getPool()
  if (!pool) return fail(res, '数据库不可用', 503, 503)
  const roots = Array.isArray(body.roots) && body.roots.length ? body.roots : localMusic.getRoots()
  if (!roots.length) return fail(res, '请先配置本机音乐文件夹路径', 400)
  try {
    const result = await localMusic.scanRoots(pool, roots, Number(body.maxDepth) || 6)
    ok(res, { roots, scanned: result.scanned, tracks: result.tracks.slice(0, 100) }, `扫描完成，发现 ${result.scanned} 个音频文件`)
  } catch (e) {
    fail(res, '扫描失败: ' + e.message, 500, 500)
  }
})

/* ================================================================== */
/* Jamendo 正版曲库                                                    */
/* ================================================================== */
route('GET', '/api/jamendo/status', async ({ res }) => {
  ok(res, await jamendo.checkConnection())
})
route('GET', '/api/jamendo/tracks', async ({ q, res }) => {
  const pool = db.getPool()
  if (!pool) return fail(res, '数据库不可用', 503, 503)
  ok(res, await jamendo.listJamendoTracks(pool, {
    keyword: q.get('keyword') || '', genre: q.get('genre') || '',
    page: q.get('page') || 1, size: q.get('size') || 50
  }))
})
route('GET', '/api/jamendo/genres', async ({ res }) => {
  const pool = db.getPool()
  if (!pool) return fail(res, '数据库不可用', 503, 503)
  ok(res, await jamendo.jamendoGenres(pool))
})
route('POST', '/api/jamendo/sync', async ({ body, res }) => {
  const pool = db.getPool()
  if (!pool) return fail(res, '数据库不可用', 503, 503)
  if (!jamendo.isConfigured()) return fail(res, '请先在 config.json 配置 Jamendo client_id')
  try {
    const result = await jamendo.syncTracks(pool, { genre: body.genre || '', limit: body.limit || 100 })
    ok(res, result, `同步完成，共 ${result.synced} 首`)
  } catch (e) {
    fail(res, '同步失败: ' + e.message, 500, 500)
  }
})

/* ================================================================== */
/* 启动                                                                */
/* ================================================================== */
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, { code: 200, msg: 'ok', data: null })
  const url = new URL(req.url, `http://localhost:${PORT}`)
  const pathname = decodeURIComponent(url.pathname)
  const body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : {}
  const ctx = { req, res, url, q: url.searchParams, path: pathname, body, params: {} }

  // 本地音频流式播放（Range），绕过统一 JSON 响应
  const streamMatch = /^\/api\/local\/stream\/(.+)$/.exec(pathname)
  if (streamMatch && req.method === 'GET') {
    const pool = db.getPool()
    if (!pool) return send(res, { code: 503, msg: '数据库不可用', data: null }, 503)
    try {
      const track = await localMusic.getLocalTrack(pool, decodeURIComponent(streamMatch[1]))
      if (!track) return send(res, { code: 404, msg: '音频不存在', data: null }, 404)
      return localMusic.streamLocalFile(req, res, track.path)
    } catch (e) {
      return send(res, { code: 500, msg: e.message, data: null }, 500)
    }
  }

  for (const r of routes) {
    if (r.method !== req.method) continue
    const m = r.regex.exec(pathname)
    if (!m) continue
    r.keys.forEach((k, i) => { ctx.params[k] = decodeURIComponent(m[i + 1]) })
    try {
      await r.handler(ctx)
    } catch (e) {
      console.error('[ERROR]', req.method, pathname, e)
      if (!res.writableEnded) fail(res, '服务器内部错误: ' + e.message, 500, 500)
    }
    return
  }
  fail(res, '接口不存在: ' + pathname, 404, 404)
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`==================================================`)
  console.log(`音乐平台后端已启动: http://127.0.0.1:${PORT}`)
  console.log(`歌曲 ${db.catalog.songs.length} 首 / 伴奏 ${db.catalog.accompaniments.length} 首 / 有声 ${db.catalog.audioZone.length} 条`)
  console.log(`演示账号: demo / 123456   VIP: vip / 123456`)
  console.log(`==================================================`)
})
