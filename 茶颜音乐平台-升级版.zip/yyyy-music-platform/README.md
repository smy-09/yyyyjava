# 茶颜音乐平台（前端 + 后端完整版）

在原有 Vue 3 前端基础上补齐了**完整后端**和**真实内容**：624 首歌曲、320 首伴奏、260 档有声节目，并实现了蝰蛇音效、听歌识曲、本地扫描、录歌修音、榜单推荐等全部要求的功能。

登录页已替换为「茶颜音乐」风格（动态光晕、漂浮音符、验证码、密码显隐、第三方登录入口），并提供 **「直接进入 · 游客体验」** 按钮——无需注册账号即可进入使用全部播放功能。

**后端已接入本地 MySQL 8.0**：曲库、账号、收藏、歌单、播放历史、录音、定时设置等全部存入 `tea_music` 数据库；连接失败会自动降级为 JSON 文件模式，不影响使用。

**真实音频接入**：除内置 624 首示例曲目外，新增两条真实音源通道——①「本地音乐」扫描你电脑里的 MP3/FLAC/WAV 等文件并直接播放；②「Jamendo 曲库」同步 CC 授权的全球正版免费音乐（需免费注册一个 client_id）。使用方法见第七节。

---

## 一、快速启动（Windows 双击即可）

1. 双击 `start.bat`
2. 浏览器打开 **http://localhost:5173**
3. 点击**「直接进入 · 游客体验」**即可免注册进入；也可用演示账号 `demo` / `123456` 登录（VIP `vip` / `123456`）

> 脚本会分别启动后端（8080）和前端（5173），关闭窗口即停止服务。

数据库已初始化完毕。换一台机器时，只需保证本机 MySQL 正常运行，然后执行一次：

```bash
cd backend
npm install
npm run init-db        # 建库建表 + 导入 624 歌曲 / 320 伴奏 / 260 有声 / 用户数据
```

**数据库连接配置**：`backend/config.json`（默认 `127.0.0.1:3306`，用户 `root`，密码 `123456`，库名 `tea_music`）。也可用环境变量 `MYSQL_HOST` / `MYSQL_PORT` / `MYSQL_USER` / `MYSQL_PASSWORD` / `MYSQL_DB` 覆盖；设置 `DB_STORAGE=json` 可强制回到文件模式。

手动启动：

```bash
# 终端 1：后端
cd backend
node server.js

# 终端 2：前端
cd frontend
npm run dev
```

前端 `vite.config.js` 已配置 `/api` → `http://127.0.0.1:8080` 代理，无需处理跨域。

---

## 二、目录结构

```
yyyy-music-platform/
├─ start.bat                 一键启动脚本
├─ backend/
│  ├─ server.js              后端主服务（全部 API）
│  ├─ config.json            MySQL 连接 + 音源配置（Jamendo key / 本地音乐目录）
│  ├─ lib/db.js              MySQL 存储层 + JSON 降级 + scrypt 加盐密码
│  ├─ lib/local-music.js     本地音频扫描 / ID3 元数据 / Range 流式播放
│  ├─ lib/jamendo.js         Jamendo API 同步与查询
│  ├─ scripts/init-db.js     建库建表 + 数据迁移（可重复执行）
│  ├─ scripts/seed.js        曲库种子生成器
│  ├─ data/                  种子源文件 & MySQL 不可用时的降级存储
│  │  ├─ catalog.json        曲库种子（624 歌曲 / 320 伴奏 / 260 有声 / 624 歌词 / 15 歌单 / 12 音效）
│  │  ├─ users.json          账号种子（首次初始化迁移到 MySQL）
│  │  └─ userdata.json       用户交互数据种子（可选）
├─ frontend/
│  ├─ src/components/        新增：分类 / 榜单 / 伴奏 / 有声 / 本地音乐 / Jamendo / 歌单 / 工具 / 搜索 / 历史 / 详情
│  ├─ src/utils/request.js   完整 API 封装
│  ├─ src/store.js           全局状态 + 所有新 action
│  ├─ src/utils/player.js    播放器增强：倍速、通用播放、LRC 时间戳
│  └─ src/styles/features.css
```

---

## 三、功能对照

### 1. 歌曲（624 首，12 个分类）
华语、流行、DJ、老歌、民谣、摇滚、日韩、欧美、纯音乐、古风、游戏 BGM、广场舞，每类 52 首；
支持分类筛选、全站搜索、热歌榜 / 飙升榜 / 新歌榜 / 原创榜、AI 推荐（按收藏偏好 + 热门 + 随机探索混合）。

### 2. 伴奏（320 首）
- 分类筛选 + 搜索，展示调性、BPM、音质、导唱标记
- **录歌**：选择伴奏 → 调性 / 升降调 / 实时修音 → 开始 / 停止 → 保存到「我的录音」
- **修音**：对已保存的录音调节升降调、修音强度、混响、自动修音开关

### 3. 有声专区（260 档）
有声小说、广播剧、相声评书、脱口秀、儿童故事、人文科普、电台、白噪音、FM 收音机；
支持分类筛选、关键词搜索、直接播放。

### 4. 播放器工具
- **蝰蛇音效**：12 种预设（蝰蛇、全景声、超重低音、3D 环绕、流行、摇滚、古典、人声、爵士、电音、夜晚、原声），各有可视化参数；基于 Web Audio API 真实作用到声音（三段均衡 + 低音增强 + 声场宽度 + 环绕延迟 + 卷积混响），点击开启、再点还原原声
- **听歌识曲**：关键词/哼唱识别 + 音频指纹识别（上传片段），返回候选歌曲与置信度
- **本地音乐扫描**：选择本机音频文件，按文件名智能匹配曲库并加入播放
- **滚动歌词 / 写真歌词**：LRC 时间戳逐行高亮，写真模式带模糊封面背景
- **倍速播放**：0.5x / 0.75x / 1x / 1.25x / 1.5x / 2x / 3x
- **定时关闭**：10/20/30/60/90 分钟或关闭，到时自动暂停
- **收藏歌单 / 自建歌单 / 最近播放 / 播放模式 / 音量**

---

## 四、接口一览

| 分组 | 接口 |
|---|---|
| 用户 | `POST /api/user/register`、`/login`，`GET /exists`、`/:id`，`PUT /profile`，`POST /:id/play` |
| 歌曲 | `GET /api/song/list`、`/:id`、`/:id/lyric`、`/:id/lrc`、`/api/categories`、`/api/charts`、`/api/recommend`、`/api/search` |
| 收藏 | `GET /api/favorite/:userId`、`POST /:userId/toggle`、`DELETE /:userId` |
| 伴奏 | `GET /api/accompaniment/categories`、`/list`、`/:id`；`POST /:id/record`；`PUT /api/recording/:id`；`GET /api/recording` |
| 有声 | `GET /api/audio-zone/categories`、`/list`、`/:id` |
| 工具 | `GET /api/effects`；`POST /api/recognize`、`/api/local/scan` |
| 个性化 | `GET/POST /api/playlist`、`POST /api/history`、`GET /api/history`、`GET/POST /api/sleep-timer`、`GET/PUT /api/settings/player` |

统一响应：`{ code: 200, msg: 'ok', data: ... }`

---

## 五、数据库维护

```bash
cd backend
node scripts/seed.js       # 重新生成 data/catalog.json 种子文件
npm run init-db            # 将种子数据同步到 MySQL（可重复执行，用户数据不丢失）
```

MySQL 中的主要表：`songs`、`lyrics`、`accompaniments`、`audio_zone`、`playlists`、`effects`、`charts`（曲库）；`users`（账号）；`user_state`（收藏/歌单/历史/录音/定时/设置，按模块存 JSON）。

查看数据示例：

```bash
mysql -u root -p tea_music -e "SELECT COUNT(*) FROM songs; SELECT id,username FROM users;"
```

---

## 六、说明与后续

- **音频源**：当前使用 SoundHelix 公开免费示例音频，仅用于演示播放器交互（需要联网）。真实商业曲库需接入有版权授权的音频 CDN，并把 `catalog.json` 中的 `src` 替换为授权地址。
- **数据存储**：默认写入本地 MySQL（`tea_music`），服务启动时从库中加载到内存，写操作按序异步落库；连接失败自动降级为 `backend/data/*.json`。密码使用 `scrypt` 加盐哈希。生产环境建议加 JWT 鉴权与连接池监控。
- **音效**：已用 Web Audio API 真实实现（均衡/低音/声场/环绕/混响），参数即时生效；因浏览器自动播放策略，需在播放音频后（用户交互）才会激活音频处理链。
- **听歌识曲 / 修音**：听歌识曲为服务端演示实现（关键词+指纹模拟匹配），录歌修音为参数化配置（未做真实音高修正 DSP）；要真实识别/修音需接入专业音频算法。

---

## 七、真实音频音源（本地音乐 / Jamendo）

内置 624 首曲目使用 SoundHelix 免费示例音频，用于演示交互。要播放**你自己的真实歌曲**或**正版免费音乐**，用下面两条通道（侧边栏「我的音乐」分组）。

### 1. 本地音乐（立即可用，无需注册）

1. 把歌曲文件（mp3 / flac / wav / m4a / aac / ogg / wma / ape）放进任意文件夹，例如 `D:\我的音乐`
2. 侧边栏进入「本地音乐」，在输入框填写文件夹绝对路径（多个用 `;` 分隔），点「🔄 扫描本地歌曲」
3. 扫描结果存入 MySQL `local_tracks` 表，双击或点「播放」即可在线播放，支持拖动进度条（HTTP Range）
4. 也可以直接改 `backend/config.json` 的 `sources.localMusic.roots` 数组，以后打开页面自动带出

> 扫描只读不写你的原始文件；不递归进入 node_modules / AppData 等系统目录，最多 6 层、5000 个文件。元数据优先取 ID3 标签，取不到则用「歌手 - 歌曲.mp3」格式的文件名解析。

### 2. Jamendo 曲库（CC 授权，合法免费）

Jamendo 要求每个应用有自己的开发者 key，没有公开可用的演示 key，需要你免费注册一个（约 2 分钟）：

1. 打开 https://devportal.jamendo.com/admin/applications 注册并登录
2. 创建应用，方案选 **Read only**（免费），拿到 `client_id`
3. 填入 `backend/config.json`：
   ```json
   "jamendo": { "clientId": "这里填你的client_id" }
   ```
   （也可用环境变量 `JAMENDO_CLIENT_ID` 覆盖，不用改文件）
4. 重启后端，侧边栏进入「Jamendo 曲库」→「检查连接」显示正常后，选风格点「同步曲目」
5. 同步的曲目存入 `jamendo_tracks` 表，点击即通过 Jamendo 官方 CDN 播放

接口：`GET /api/jamendo/status`、`POST /api/jamendo/sync`、`GET /api/jamendo/tracks`、`GET /api/jamendo/genres`；本地音乐接口为 `GET/POST /api/local/roots`（读取/保存文件夹配置）、`POST /api/local/scan`、`GET /api/local/tracks`、`GET /api/local/stream/:id`。

**说明**：周杰伦、Taylor Swift 等商业歌曲受版权保护，本项目不提供、也不抓取盗版音源；请用你自己的合法音频文件或 Jamendo 等授权曲库。
