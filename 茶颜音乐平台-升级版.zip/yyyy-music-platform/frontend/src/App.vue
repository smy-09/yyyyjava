<template>
  <!-- 可更换的背景层 -->
  <div class="bg-layer" :style="{ background: bgStyle(state.profile.bg) }"></div>

  <LoginPage v-if="!state.logged" />

  <div class="app" v-else>
    <TopBar />
    <div class="layout">
      <SideBar />
      <main class="content">
        <HomeView v-if="state.view === 'home'" />
        <FavView v-else-if="state.view === 'fav'" />
        <CategoryView v-else-if="state.view === 'category'" />
        <ChartsView v-else-if="state.view === 'charts'" />
        <AccompanimentView v-else-if="state.view === 'accompaniment'" />
        <AudioZoneView v-else-if="state.view === 'audiozone'" />
        <LocalMusicView v-else-if="state.view === 'local'" />
        <JamendoView v-else-if="state.view === 'jamendo'" />
        <PlaylistView v-else-if="state.view === 'playlist'" />
        <ToolsView v-else-if="state.view === 'tools'" />
        <SearchView v-else-if="state.view === 'search'" />
        <HistoryView v-else-if="state.view === 'history'" />
        <ProfileView v-else-if="state.view === 'profile'" />
        <ThemeView v-else-if="state.view === 'theme'" />
      </main>
      <NowPlaying />
    </div>
    <PlayerBar />
  </div>

  <DetailModal v-if="state.detailModal" />
  <Toast />
</template>

<script setup>
import { onMounted } from 'vue'
import { state, actions, bgStyle } from './store'
import LoginPage from './components/LoginPage.vue'
import TopBar from './components/TopBar.vue'
import SideBar from './components/SideBar.vue'
import HomeView from './components/HomeView.vue'
import FavView from './components/FavView.vue'
import CategoryView from './components/CategoryView.vue'
import ChartsView from './components/ChartsView.vue'
import AccompanimentView from './components/AccompanimentView.vue'
import AudioZoneView from './components/AudioZoneView.vue'
import LocalMusicView from './components/LocalMusicView.vue'
import JamendoView from './components/JamendoView.vue'
import PlaylistView from './components/PlaylistView.vue'
import ToolsView from './components/ToolsView.vue'
import SearchView from './components/SearchView.vue'
import HistoryView from './components/HistoryView.vue'
import DetailModal from './components/DetailModal.vue'
import ProfileView from './components/ProfileView.vue'
import ThemeView from './components/ThemeView.vue'
import NowPlaying from './components/NowPlaying.vue'
import PlayerBar from './components/PlayerBar.vue'
import Toast from './components/Toast.vue'

onMounted(async () => {
  await actions.bootstrap()
  if (state.logged) {
    await actions.loadPlayerSettings()
    await actions.loadRecordings()
    await actions.loadRecommend()
  }
  actions.toast(state.online ? '已连接后端服务 · 曲库已就绪' : '后端未连接，当前为本地演示模式')
})
</script>
