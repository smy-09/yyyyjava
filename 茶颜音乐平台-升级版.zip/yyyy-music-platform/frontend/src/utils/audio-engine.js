/**
 * Web Audio 音效引擎：把「蝰蛇音效」等预设参数真正作用到音频上。
 * 信号链：MediaElementSource → 低音提升 → 三段均衡 → 声场宽度 → 环绕延迟 → 混响 → 输出
 * 浏览器要求用户首次交互后才能启动 AudioContext，故采用懒初始化。
 */
import { state } from '../store'

let ctx = null
let source = null
let nodes = null
let currentEffectId = null
let enabled = true

function dbToGain(v) {
  // 0-100 → -12dB..+12dB 的增益
  const db = ((Number(v) || 50) - 50) / 50 * 12
  return Math.pow(10, db / 20)
}

function makeReverbIR(context, seconds = 1.6, decay = 2.5) {
  const rate = context.sampleRate
  const len = Math.floor(rate * seconds)
  const buf = context.createBuffer(2, len, rate)
  for (let ch = 0; ch < 2; ch++) {
    const data = buf.getChannelData(ch)
    for (let i = 0; i < len; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay)
    }
  }
  return buf
}

/** 懒初始化：创建常驻音频节点链 */
function ensureChain(audioEl) {
  if (ctx) return true
  const AC = window.AudioContext || window.webkitAudioContext
  if (!AC) return false
  try {
    ctx = new AC()
    source = ctx.createMediaElementSource(audioEl)

    const bassBoost = ctx.createBiquadFilter()
    bassBoost.type = 'lowshelf'; bassBoost.frequency.value = 180

    const low = ctx.createBiquadFilter()
    low.type = 'peaking'; low.frequency.value = 200; low.Q.value = 0.8
    const mid = ctx.createBiquadFilter()
    mid.type = 'peaking'; mid.frequency.value = 1200; mid.Q.value = 0.9
    const high = ctx.createBiquadFilter()
    high.type = 'highshelf'; high.frequency.value = 5000

    const widthLeft = ctx.createGain(), widthRight = ctx.createGain()
    const splitter = ctx.createChannelSplitter(2)
    const merger = ctx.createChannelMerger(2)

    const surroundDelay = ctx.createDelay(0.5)
    surroundDelay.delayTime.value = 0.08
    const surroundGain = ctx.createGain()
    surroundGain.gain.value = 0

    const convolver = ctx.createConvolver()
    convolver.buffer = makeReverbIR(ctx)
    const wet = ctx.createGain(); wet.gain.value = 0
    const dry = ctx.createGain(); dry.gain.value = 1

    const master = ctx.createGain(); master.gain.value = 1

    // 连接信号链
    source.connect(bassBoost)
    bassBoost.connect(low); low.connect(mid); mid.connect(high)
    high.connect(splitter)
    splitter.connect(widthLeft, 0); splitter.connect(widthRight, 1)
    widthLeft.connect(merger, 0, 0); widthRight.connect(merger, 0, 1)
    merger.connect(dry); dry.connect(master)
    merger.connect(surroundDelay); surroundDelay.connect(surroundGain); surroundGain.connect(master)
    merger.connect(convolver); convolver.connect(wet); wet.connect(master)
    master.connect(ctx.destination)

    nodes = { bassBoost, low, mid, high, widthLeft, widthRight, surroundDelay, surroundGain, wet, dry, master }
    return true
  } catch (e) {
    console.warn('[音效引擎] 初始化失败，将使用原始音频输出:', e.message)
    ctx = null
    return false
  }
}

function param(params, name, fallback = 50) {
  if (!params) return fallback
  if (params[name] != null) return Number(params[name])
  // 兼容英文别名
  const alias = { 低音: ['bass'], 中音: ['mid'], 高音: ['treble'], 混响: ['reverb'], 环绕强度: ['surround'] }[name] || []
  for (const a of alias) if (params[a] != null) return Number(params[a])
  return fallback
}

/** 应用音效预设（effectId 对应后端 /api/effects 的 id） */
export function applyEffect(audioEl, effectId, effects = []) {
  currentEffectId = effectId
  if (!enabled || effectId === 'original' || !effectId) {
    // 关闭音效：旁路——把增益归一，混响/环绕归零
    if (nodes) {
      const t = ctx.currentTime
      nodes.bassBoost.gain.setTargetAtTime(0, t, 0.05)
      nodes.low.gain.setTargetAtTime(0, t, 0.05)
      nodes.mid.gain.setTargetAtTime(0, t, 0.05)
      nodes.high.gain.setTargetAtTime(0, t, 0.05)
      nodes.wet.gain.setTargetAtTime(0, t, 0.05)
      nodes.surroundGain.gain.setTargetAtTime(0, t, 0.05)
      nodes.widthLeft.gain.setTargetAtTime(1, t, 0.05)
      nodes.widthRight.gain.setTargetAtTime(1, t, 0.05)
      nodes.dry.gain.setTargetAtTime(1, t, 0.05)
    }
    return false
  }
  if (!ensureChain(audioEl)) return false
  if (ctx.state === 'suspended') ctx.resume().catch(() => {})

  const preset = effects.find((e) => e.id === effectId)
  const p = preset?.params || {}
  const t = ctx.currentTime
  const set = (node, value) => node.gain.setTargetAtTime(value, t, 0.08)

  // 三段均衡：50 → 0dB
  set(nodes.low, dbToGain(param(p, '低音')) - 1)
  set(nodes.mid, dbToGain(param(p, '中音', 50)) - 1)
  set(nodes.high, dbToGain(param(p, '高音')) - 1)

  // 低音增强（lowshelf）
  const bassBoost = param(p, '低音增强', param(p, '低音', 50))
  nodes.bassBoost.gain.setTargetAtTime(dbToGain(bassBoost) - 1, t, 0.08)

  // 声场宽度：通过调整左右声道增益差实现
  const width = param(p, '声场宽度', 50) / 100
  const w = 1 + width * 0.5
  set(nodes.widthLeft, w)
  set(nodes.widthRight, 2 - w)

  // 环绕：延迟混音
  const surround = param(p, '环绕强度', param(p, '头部追踪', 0)) / 100
  set(nodes.surroundGain, surround * 0.35)
  nodes.surroundDelay.delayTime.setTargetAtTime(0.05 + surround * 0.12, t, 0.08)

  // 混响湿度
  const reverb = param(p, '混响', 0) / 100
  set(nodes.wet, reverb * 0.6)
  set(nodes.dry, 1 - reverb * 0.25)

  return true
}

/** 切换音效总开关 */
export function setEffectEnabled(value) {
  enabled = Boolean(value)
  return enabled
}

export function getEffectState() {
  return { enabled, effectId: currentEffectId, supported: Boolean(window.AudioContext || window.webkitAudioContext) }
}

/** 在用户首次交互时恢复 AudioContext（浏览器自动播放策略） */
export function unlockAudio() {
  if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {})
}

/** 供播放器调用的初始化入口 */
export function initAudioEngine(audioEl) {
  return ensureChain(audioEl)
}
