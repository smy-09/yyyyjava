/**
 * 后端接口封装。
 *  1. 统一走 /api 前缀，由 vite proxy 转发到后端 8080；
 *  2. 后端统一返回 { code, msg, data }，这里统一拆包；
 *  3. 每个请求带上 X-User-Id；
 *  4. 后端没起来时抛错，store 里降级到本地兜底。
 */
const BASE = ''

let currentUserId = null
export function setCurrentUserId(id) { currentUserId = id }
export function getCurrentUserId() { return currentUserId }

const TIMEOUT = 8000

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) }
  if (currentUserId != null) headers['X-User-Id'] = String(currentUserId)
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), TIMEOUT)
  try {
    const res = await fetch(BASE + path, { ...options, headers, signal: controller.signal })
    if (!res.ok) throw new Error('HTTP ' + res.status)
    const body = await res.json()
    if (body.code !== 200) {
      const err = new Error(body.msg || '请求失败')
      err.code = body.code
      throw err
    }
    return body.data
  } finally {
    clearTimeout(timer)
  }
}
const qs = (obj) => {
  const p = new URLSearchParams()
  Object.entries(obj || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p.set(k, String(v))
  })
  const s = p.toString()
  return s ? '?' + s : ''
}
const post = (path, body) => request(path, { method: 'POST', body: JSON.stringify(body || {}) })
const put = (path, body) => request(path, { method: 'PUT', body: JSON.stringify(body || {}) })
const del = (path) => request(path, { method: 'DELETE' })

export const api = {
  /* 用户 */
  register: (payload) => post('/api/user/register', payload),
  login: (payload) => post('/api/user/login', payload),
  exists: (username) => request('/api/user/exists' + qs({ username })),
  getUser: (id) => request('/api/user/' + id),
  updateProfile: (patch) => put('/api/user/profile', patch),
  addPlayCount: (userId) => post('/api/user/' + userId + '/play'),

  /* 歌曲 / 歌词 */
  listSongs: (keyword) => request('/api/song/list' + qs({ keyword })),
  querySongs: (params) => request('/api/song/list' + qs(params)),
  getSong: (id) => request('/api/song/' + id),
  listLyric: (songId) => request('/api/song/' + songId + '/lyric'),
  getLrc: (songId) => request('/api/song/' + songId + '/lrc'),
  categories: () => request('/api/categories'),
  charts: (type, limit) => request('/api/charts' + qs({ type, limit })),
  recommend: (userId, limit) => request('/api/recommend' + qs({ userId, limit })),
  search: (keyword, type) => request('/api/search' + qs({ q: keyword, type })),

  /* 收藏 */
  listFavorites: (userId) => request('/api/favorite/' + userId),
  toggleFavorite: (userId, songId) => post('/api/favorite/' + userId + '/toggle', { songId }),
  clearFavorites: (userId) => del('/api/favorite/' + userId),

  /* 伴奏 / 录歌 / 修音 */
  accCategories: () => request('/api/accompaniment/categories'),
  accList: (params) => request('/api/accompaniment/list' + qs(params)),
  accDetail: (id) => request('/api/accompaniment/' + id),
  startRecord: (id, payload) => post('/api/accompaniment/' + id + '/record', payload),
  myRecordings: () => request('/api/recording'),
  tuneRecording: (id, payload) => put('/api/recording/' + id, payload),

  /* 有声专区 */
  azCategories: () => request('/api/audio-zone/categories'),
  azList: (params) => request('/api/audio-zone/list' + qs(params)),
  azDetail: (id) => request('/api/audio-zone/' + id),

  /* 音效 / 工具 */
  effects: () => request('/api/effects'),
  effect: (id) => request('/api/effects/' + id),
  recognize: (payload) => post('/api/recognize', payload),
  localScan: (files) => post('/api/local/scan', { files }),

  /* 本地音乐库（真实文件） */
  localRoots: () => request('/api/local/roots'),
  saveLocalRoots: (roots) => post('/api/local/roots', { roots }),
  localTracks: (params) => request('/api/local/tracks' + qs(params)),
  scanLocalDirs: (roots, maxDepth) => post('/api/local/scan', { roots, maxDepth }),
  localStream: (id) => '/api/local/stream/' + encodeURIComponent(id),

  /* Jamendo 正版曲库 */
  jamendoStatus: () => request('/api/jamendo/status'),
  jamendoTracks: (params) => request('/api/jamendo/tracks' + qs(params)),
  jamendoGenres: () => request('/api/jamendo/genres'),
  jamendoSync: (payload) => post('/api/jamendo/sync', payload),

  /* 歌单 / 历史 / 定时 / 设置 */
  playlists: () => request('/api/playlist'),
  createPlaylist: (payload) => post('/api/playlist', payload),
  deletePlaylist: (id) => del('/api/playlist/' + id),
  playlistSongs: (id, payload) => post('/api/playlist/' + id + '/songs', payload),
  addHistory: (songId) => post('/api/history', { songId }),
  history: (limit) => request('/api/history' + qs({ limit })),
  sleepTimer: (payload) => payload ? post('/api/sleep-timer', payload) : request('/api/sleep-timer'),
  getPlayerSettings: () => request('/api/settings/player'),
  savePlayerSettings: (patch) => put('/api/settings/player', patch),

  health: () => request('/api/health')
}

export async function pingBackend() {
  try {
    await request('/api/song/list')
    return true
  } catch (e) {
    return false
  }
}
