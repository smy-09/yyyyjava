// 播放器：单例 Audio 元素 + 一组控制方法，状态同步回 store
import { state, actions, registerSpeedHook } from '../store'
import { applyEffect, setEffectEnabled, unlockAudio } from './audio-engine'

const audio = new Audio()
audio.volume = state.volume

function setPlaying(p) { state.playing = p }
function list() { return state.songs }

/** 解析 LRC 为 [{time, text}] */
export function parseLrc(lrc) {
  if (!lrc) return []
  const out = []
  lrc.split('\n').forEach((line) => {
    const m = /^\[(\d{2}):(\d{2})(?:\.(\d{1,3}))?\](.*)$/.exec(line.trim())
    if (m) out.push({ time: Number(m[1]) * 60 + Number(m[2]), text: m[4] })
  })
  return out
}

/** 把伴奏 / 有声 / 本地音乐 / Jamendo 转换为可播放的队列项 */
function toQueueItem(item, type) {
  const prefix = { acc: 'acc', az: 'az', local: 'local', jamendo: 'jam' }[type] || 'x'
  return {
    id: `${prefix}-${item.id}`,
    title: item.title || item.name,
    artist: item.artist || item.host || '未知',
    album: item.album || item.category || '',
    src: type === 'local' ? `/api/local/stream/${encodeURIComponent(item.id)}` : item.src || item.audio,
    cover: item.cover || item.image || '',
    dur: item.duration || 0,
    category: item.category || item.genre || '',
    sourceType: type
  }
}

export const player = {
  el: audio,

  play(i) {
    const songs = list()
    if (!songs[i]) return
    state.current = i
    state.profile.playCount++
    actions.save()

    if (state.online && state.userId) actions.addPlayCountSilently(state.userId)
    actions.loadLyric(i)
    actions.addHistory(songs[i])

    audio.src = songs[i].src
    audio.playbackRate = Number(state.playerSettings.speed) || 1
    unlockAudio()
    // 应用当前音效（首次会创建音频处理链，后续仅更新参数）
    applyEffect(audio, state.playerSettings.effectId, state.effects)
    const p = audio.play()
    if (p && p.then) {
      p.then(() => setPlaying(true)).catch(() => {
        setPlaying(true)
        actions.toast('音频加载中，请稍候…')
      })
    } else setPlaying(true)
  },

  /** 播放任意内容（歌曲 / 伴奏 / 有声） */
  playItem(item, type = 'song') {
    if (type === 'song') {
      const idx = state.songs.findIndex((s) => s.id === item.id)
      this.play(idx >= 0 ? idx : 0)
      return
    }
    const converted = toQueueItem(item, type)
    let idx = state.songs.findIndex((s) => s.id === converted.id)
    if (idx < 0) { state.songs.push(converted); idx = state.songs.length - 1 }
    this.play(idx)
  },

  toggle() {
    if (state.current < 0) return this.play(0)
    if (state.playing) { audio.pause(); setPlaying(false) }
    else { audio.play(); setPlaying(true) }
  },

  next() {
    const songs = list()
    if (state.current < 0) return this.play(0)
    if (state.mode === 2) { audio.currentTime = 0; audio.play(); return }
    const i = state.mode === 1 ? Math.floor(Math.random() * songs.length) : (state.current + 1) % songs.length
    this.play(i)
  },

  prev() {
    const songs = list()
    if (state.current < 0) return this.play(0)
    this.play((state.current - 1 + songs.length) % songs.length)
  },

  cycleMode() {
    state.mode = (state.mode + 1) % 3
    actions.toast('播放模式：' + ['顺序', '随机', '单曲'][state.mode])
  },

  seek(ratio) { if (audio.duration) audio.currentTime = ratio * audio.duration },

  setVolume(ratio) {
    audio.volume = ratio
    state.volume = ratio
  },

  setSpeed(speed) {
    const s = Math.min(3, Math.max(0.5, Number(speed) || 1))
    audio.playbackRate = s
    state.playerSettings.speed = s
    actions.savePlayerSettings({ speed: s })
  },

  /** 切换音效（实时作用于音频处理链） */
  setEffect(effectId) {
    state.playerSettings.effectId = effectId
    actions.savePlayerSettings({ effectId })
    applyEffect(audio, effectId, state.effects)
  },

  /** 音效总开关 */
  toggleEffect(enabled) {
    setEffectEnabled(enabled)
    applyEffect(audio, state.playerSettings.effectId, state.effects)
  }
}

// 让 store 可以反向调用播放器设置倍速（避免循环依赖）
registerSpeedHook((speed) => { audio.playbackRate = Number(speed) || 1 })

audio.addEventListener('timeupdate', () => {
  state.curTime = audio.currentTime
  state.duration = audio.duration || 0

  // 定时关闭
  const t = state.sleepTimer
  if (t && t.enabled) {
    if (t.triggerAt && Date.now() >= new Date(t.triggerAt).getTime()) {
      audio.pause(); setPlaying(false)
      state.sleepTimer = { enabled: false }
      actions.toast('定时关闭已生效，晚安 🌙')
      if (state.online) actions.setSleepTimer(0)
    } else if (t.remainingMinutes != null && t.remainingMinutes <= 0) {
      audio.pause(); setPlaying(false)
      state.sleepTimer = { enabled: false }
      actions.toast('定时关闭已生效，晚安 🌙')
    }
  }

  // 歌词高亮：优先按 LRC 时间戳
  const lrc = actions.currentLrcLines ? actions.currentLrcLines() : []
  if (lrc.length && lrc[0].time != null) {
    let idx = 0
    for (let i = 0; i < lrc.length; i++) {
      if (audio.currentTime >= lrc[i].time) idx = i
      else break
    }
    if (idx !== state.lyricIndex) state.lyricIndex = idx
  } else if (state.lyrics.length) {
    const next = Math.min(state.lyrics.length - 1, Math.floor(audio.currentTime / 7))
    if (next !== state.lyricIndex) state.lyricIndex = next
  }
})

audio.addEventListener('ended', () => {
  if (state.mode !== 2) player.next()
  else { audio.currentTime = 0; audio.play() }
})

audio.addEventListener('error', () => {
  if (state.current >= 0) actions.toast('音频加载失败，请检查网络连接')
})
