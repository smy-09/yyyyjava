<template>
  <div class="ty-login-root">
    <!-- 动态光晕 -->
    <div class="ty-orbs">
      <div class="ty-orb ty-orb-1"></div>
      <div class="ty-orb ty-orb-2"></div>
      <div class="ty-orb ty-orb-3"></div>
    </div>
    <div class="ty-particles">
      <span v-for="(n, i) in particles" :key="i" class="ty-particle"
            :style="{ left: n.left, fontSize: n.size, animationDuration: n.dur, animationDelay: n.delay }">{{ n.icon }}</span>
    </div>

    <div class="ty-wrap">
      <div class="ty-card">
        <!-- 左侧品牌区 -->
        <section class="ty-brand">
          <div class="ty-brand-top">
            <div class="ty-logo-disc">🎵</div>
            <div class="ty-logo-name">茶颜<span>音乐</span></div>
          </div>

          <div class="ty-brand-mid">
            <h1>听见好茶颜<br>遇见<b>好音乐</b></h1>
            <p>千万曲库、沉浸式音效与深夜电台，登录后同步你的歌单、收藏与听歌偏好，随时随地接着听。</p>
            <div class="ty-feat">
              <div class="ty-feat-item">
                <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V6l10-2v11"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="15" r="2.5"/></svg></div>
                海量正版曲库，流行经典一网打尽
              </div>
              <div class="ty-feat-item">
                <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12a8 8 0 0 1 16 0M7 16a5 5 0 0 1 10 0M10 20a2 2 0 0 1 4 0"/></svg></div>
                蝰蛇级音效，3D 环绕沉浸聆听
              </div>
              <div class="ty-feat-item">
                <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6c-2.5 4.5-9.5 9-9.5 9Z"/></svg></div>
                歌单云端同步，换设备不丢失
              </div>
            </div>
          </div>

          <div class="ty-brand-disc"></div>
        </section>

        <!-- 右侧表单区 -->
        <section class="ty-form-side">
          <div class="ty-tabs">
            <button class="ty-tab" :class="{ active: mode === 'login' }" @click="switchTab('login')">登录</button>
            <button class="ty-tab" :class="{ active: mode === 'reg' }" @click="switchTab('reg')">注册</button>
          </div>

          <form @submit.prevent="submitForm">
            <div class="ty-field">
              <label>账号</label>
              <div class="ty-input-box">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></svg>
                <input v-model.trim="account" type="text" placeholder="手机号 / 邮箱 / 用户名" autocomplete="username" maxlength="30" />
              </div>
            </div>

            <div class="ty-field">
              <label>密码</label>
              <div class="ty-input-box">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                <input v-model="password" :type="showPwd ? 'text' : 'password'" placeholder="请输入密码" autocomplete="current-password" maxlength="30" />
                <button type="button" class="ty-eye" @click="showPwd = !showPwd" title="显示/隐藏密码">
                  <svg v-if="!showPwd" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:18px;height:18px"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                  <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:18px;height:18px"><path d="M3 3l18 18M10.6 5.1A9.8 9.8 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 3.9M6.1 6.2A16.6 16.6 0 0 0 2 12s3.5 7 10 7c1.7 0 3.3-.5 4.7-1.3"/></svg>
                </button>
              </div>
            </div>

            <div class="ty-field" id="captchaField">
              <label>验证码</label>
              <div class="ty-captcha-row">
                <div class="ty-input-box">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 4 6v6c0 5 3.4 8.5 8 9 4.6-.5 8-4 8-9V6z"/></svg>
                  <input v-model.trim="captcha" type="text" placeholder="输入右侧验证码" maxlength="4" />
                </div>
                <div class="ty-captcha-img" title="点击刷新" @click="genCaptcha">{{ captchaCode }}</div>
              </div>
            </div>

            <div class="ty-row">
              <label class="ty-remember"><input type="checkbox" v-model="remember" /> 记住我</label>
              <a class="ty-forgot" @click="actions.toast('演示账号：demo / 123456')">忘记密码？</a>
            </div>

            <div class="ty-err">{{ err }}</div>

            <button type="submit" class="ty-submit" :class="{ loading: submitting }">
              {{ submitting ? '正在处理…' : (mode === 'login' ? '登 录' : '注 册') }}
            </button>

            <!-- 游客直接进入 -->
            <button type="button" class="ty-guest" @click="guestEnter">
              <span class="ty-guest-ic">🚀</span>
              <span class="ty-guest-body"><b>直接进入 · 游客体验</b><small>无需注册账号，立即畅听完整曲库</small></span>
              <span class="ty-guest-arrow">→</span>
            </button>

            <div class="ty-divider">其他登录方式</div>
            <div class="ty-third">
              <button type="button" class="ty-third-btn wx" title="微信" @click="actions.toast('微信登录（演示）')">微</button>
              <button type="button" class="ty-third-btn qq" title="QQ" @click="actions.toast('QQ 登录（演示）')">Q</button>
              <button type="button" class="ty-third-btn wb" title="微博" @click="actions.toast('微博登录（演示）')">博</button>
              <button type="button" class="ty-third-btn gg" title="Apple" @click="actions.toast('Apple 登录（演示）')">A</button>
            </div>

            <p class="ty-agreement">登录即代表你已阅读并同意 <a @click="actions.toast('演示版本，协议略')">《用户协议》</a> 与 <a @click="actions.toast('演示版本，隐私政策略')">《隐私政策》</a></p>
            <p class="ty-demo-tip">演示账号：<b>demo / 123456</b>　·　也可直接点上方「直接进入」</p>
          </form>
        </section>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { actions, state } from '../store'

const mode = ref('login')
const account = ref('')
const password = ref('')
const captcha = ref('')
const captchaCode = ref('')
const showPwd = ref(false)
const remember = ref(true)
const submitting = ref(false)
const err = ref('')
const particles = ref([])

const notes = ['♪', '♫', '♩', '♬']
onMounted(() => {
  particles.value = Array.from({ length: 18 }, () => ({
    icon: notes[Math.floor(Math.random() * notes.length)],
    left: Math.random() * 100 + '%',
    size: 14 + Math.random() * 16 + 'px',
    dur: 9 + Math.random() * 12 + 's',
    delay: Math.random() * 10 + 's'
  }))
  genCaptcha()
  if (state.loginPrefill) {
    account.value = state.loginPrefill
    state.loginPrefill = ''
  }
})

function genCaptcha() {
  captchaCode.value = Math.floor(1000 + Math.random() * 9000).toString()
}
function switchTab(m) {
  mode.value = m
  err.value = ''
  captcha.value = ''
  genCaptcha()
}

async function submitForm() {
  if (submitting.value) return
  err.value = ''
  if (!account.value) { err.value = '请输入账号'; return }
  if (!password.value) { err.value = '请输入密码'; return }
  if (mode.value === 'reg' && password.value.length < 6) { err.value = '密码至少 6 位'; return }
  if (!captcha.value) { err.value = '请输入验证码'; return }
  if (captcha.value.toLowerCase() !== captchaCode.value.toLowerCase()) {
    err.value = '验证码不正确'
    genCaptcha()
    return
  }

  submitting.value = true
  if (mode.value === 'login') {
    const res = await actions.login(account.value, password.value)
    submitting.value = false
    if (res && !res.ok) {
      err.value = res.msg || '登录失败'
      genCaptcha()
    }
  } else {
    const res = await actions.register({ username: account.value, phone: '', password: password.value })
    submitting.value = false
    if (res && res.ok) {
      mode.value = 'login'
      err.value = ''
      actions.toast('注册成功，请登录')
      genCaptcha()
    } else {
      err.value = res?.msg || '注册失败'
      genCaptcha()
    }
  }
}

function guestEnter() {
  actions.guestLogin()
}
</script>
