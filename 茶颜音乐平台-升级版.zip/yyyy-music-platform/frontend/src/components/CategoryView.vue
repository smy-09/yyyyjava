<template>
  <section>
    <div class="page-head">
      <h2>歌曲分类</h2>
      <p>华语 · 流行 · DJ · 老歌 · 民谣 · 摇滚 · 日韩 · 欧美 · 纯音乐 · 古风 · 游戏 BGM · 广场舞</p>
    </div>

    <div class="chip-row">
      <span class="chip" :class="{ on: state.activeCategory === '全部' }" @click="pick('全部')">全部</span>
      <span v-for="c in state.categories" :key="c.name" class="chip"
            :class="{ on: state.activeCategory === c.name }" @click="pick(c.name)">
        {{ c.icon }} {{ c.name }}
      </span>
    </div>

    <div class="section-title">
      <span>{{ state.activeCategory }} · 共 {{ rows.length }} 首</span>
      <a @click="playAll">▶ 播放全部</a>
    </div>
    <SongList :items="rows" empty-text="加载中或暂无数据…" />
  </section>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { state, actions } from '../store'
import { player } from '../utils/player'
import SongList from './SongList.vue'

const rows = computed(() => state.categorySongs.map((s, pos) => {
  const i = state.songs.findIndex((x) => x.id === s.id)
  return i >= 0 ? { i, pos: pos + 1 } : null
}).filter(Boolean))

function pick(name) { actions.showCategory(name) }
function playAll() {
  if (rows.value.length) player.play(rows.value[0].i)
  else actions.toast('暂无歌曲')
}
onMounted(() => {
  if (state.activeCategory === '全部' || !state.categorySongs.length) actions.showCategory('全部')
})
</script>
