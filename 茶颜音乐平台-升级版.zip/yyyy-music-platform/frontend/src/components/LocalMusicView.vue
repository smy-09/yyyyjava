<template>
  <div class="page feature-page">
    <div class="page-head">
      <div>
        <h2>🎼 本地音乐</h2>
        <p class="sub">扫描你电脑里的歌曲，直接在线播放——不上传、不修改任何原始文件</p>
      </div>
      <button class="btn primary" @click="doScan" :disabled="scanning">
        {{ scanning ? '扫描中…' : '🔄 扫描本地歌曲' }}
      </button>
    </div>

    <div class="card setup-card">
      <div class="setup-title">📁 音乐文件夹</div>
      <p class="hint">填写存放歌曲的文件夹路径（多个用分号分隔），也可以留空使用后端 config.json 里配置的目录。<br>例如：<code>C:\Users\Administrator\Music;D:\我的音乐</code></p>
      <div class="input-row">
        <input v-model="rootsText" placeholder="输入本机音乐文件夹的绝对路径，多个用 ; 分隔" />
        <button class="btn" @click="saveRoots">保存</button>
      </div>
      <div class="status-row" v-if="statusMsg">{{ statusMsg }}</div>
    </div>

    <div class="card">
      <div class="list-head">
        <div class="setup-title">曲库（{{ tracks.length }}）</div>
        <input v-model="keyword" @keyup.enter="loadTracks" placeholder="搜索歌曲 / 歌手" class="search-input" />
      </div>
      <div v-if="!tracks.length" class="empty">
        <div class="empty-icon">🎵</div>
        <p>还没有本地歌曲</p>
        <p class="hint">把 MP3 / FLAC / WAV / M4A 等文件放进上面的文件夹，然后点「扫描本地歌曲」</p>
      </div>
      <div v-else class="track-list">
        <div class="track" v-for="(t, i) in tracks" :key="t.id" @dblclick="play(t)">
          <div class="track-index">{{ String(i + 1).padStart(2, '0') }}</div>
          <div class="track-info">
            <div class="track-title">{{ t.title }}</div>
            <div class="track-artist">{{ t.artist }}<span v-if="t.album"> · {{ t.album }}</span></div>
          </div>
          <div class="track-size">{{ formatSize(t.size) }}</div>
          <button class="btn small" @click.stop="play(t)">▶ 播放</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { api } from '../utils/request'
import { player } from '../utils/player'

const rootsText = ref('')
const keyword = ref('')
const tracks = ref([])
const scanning = ref(false)
const statusMsg = ref('')

async function loadRoots() {
  try {
    const roots = await api.localRoots()
    rootsText.value = (roots || []).join(';')
  } catch (e) { statusMsg.value = '读取目录配置失败：' + e.message }
}
async function saveRoots() {
  const roots = rootsText.value.split(';').map((s) => s.trim()).filter(Boolean)
  if (!roots.length) { statusMsg.value = '请先填写至少一个文件夹路径'; return }
  try {
    const saved = await api.saveLocalRoots(roots)
    rootsText.value = saved.join(';')
    statusMsg.value = `已保存 ${saved.length} 个文件夹路径到后端配置，下次打开会自动带出。`
  } catch (e) { statusMsg.value = '保存失败：' + e.message }
}
async function loadTracks() {
  try {
    const r = await api.localTracks({ keyword: keyword.value, size: 200 })
    tracks.value = r.list || []
  } catch (e) { statusMsg.value = '加载失败：' + e.message }
}
async function doScan() {
  const roots = rootsText.value.split(';').map((s) => s.trim()).filter(Boolean)
  if (!roots.length) { statusMsg.value = '请先填写音乐文件夹路径'; return }
  scanning.value = true
  statusMsg.value = '正在扫描，请稍候…'
  try {
    const r = await api.scanLocalDirs(roots, 6)
    statusMsg.value = `扫描完成：发现 ${r.scanned} 个音频文件`
    await loadTracks()
  } catch (e) {
    statusMsg.value = '扫描失败：' + e.message
  } finally { scanning.value = false }
}
function play(t) { player.playItem(t, 'local') }
function formatSize(n) {
  if (!n) return '—'
  return n > 1024 * 1024 ? (n / 1024 / 1024).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB'
}
onMounted(() => { loadRoots(); loadTracks() })
</script>
