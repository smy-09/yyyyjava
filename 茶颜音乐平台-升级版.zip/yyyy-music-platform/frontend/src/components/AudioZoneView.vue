<template>
  <section>
    <div class="page-head">
      <h2>📖 有声专区</h2>
      <p>有声小说、广播剧、相声评书、脱口秀、儿童故事、人文科普、电台、白噪音、FM 收音机</p>
    </div>

    <div class="chip-row">
      <span class="chip" :class="{ on: !azFilter }" @click="pick('')">全部</span>
      <span v-for="c in state.azCategories" :key="c.name" class="chip"
            :class="{ on: azFilter === c.name }" @click="pick(c.name)">
        {{ c.icon }} {{ c.name }} <small>{{ c.count }}</small>
      </span>
    </div>

    <div class="section-title">
      <span>{{ azFilter || '全部内容' }} · {{ rows.length }} 档</span>
      <input v-model="azKeyword" class="mini-input" placeholder="搜索有声内容…" @keyup.enter="search" />
    </div>

    <div class="az-grid">
      <div v-for="a in rows" :key="a.id" class="az-card" @click="player.playItem(a, 'az')">
        <div class="az-cover" :style="{ background: a.cover }">
          <span class="az-ic">{{ iconOf(a.category) }}</span>
          <span class="az-play">▶</span>
        </div>
        <div class="az-title">{{ a.title }}</div>
        <div class="az-sub">{{ a.host }} · {{ a.episodes }} 集 · {{ fmtTime(a.duration) }}</div>
        <div class="az-tag">{{ a.category }}</div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref, onMounted } from 'vue'
import { state, actions } from '../store'
import { player } from '../utils/player'

const azFilter = ref('')
const azKeyword = ref('')
const rows = computed(() => state.azList)
const iconOf = (c) => ({
  '有声小说': '📖', '广播剧': '🎭', '相声评书': '🎙️', '脱口秀': '😂', '儿童故事': '🧸',
  '人文科普': '📚', '电台': '📻', '白噪音': '🌙', 'FM收音机': '📡'
}[c] || '🎧')
const fmtTime = (s) => {
  const n = Math.floor(s || 0)
  return n > 3600 ? `${Math.floor(n / 3600)} 小时` : `${Math.floor(n / 60)} 分钟`
}
function pick(name) { azFilter.value = name; actions.loadAudioZone(name, azKeyword.value) }
function search() { actions.loadAudioZone(azFilter.value, azKeyword.value) }
onMounted(() => { if (!state.azList.length) actions.loadAudioZone() })
</script>
