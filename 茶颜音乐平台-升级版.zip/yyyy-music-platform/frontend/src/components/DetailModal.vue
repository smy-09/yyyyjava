<template>
  <div class="modal-mask" @click.self="state.detailModal = null">
    <div class="modal">
      <div class="modal-head">{{ state.detailModal.title }} <span @click="state.detailModal = null">✕</span></div>
      <div class="modal-body">
        <div v-for="(r, i) in state.detailModal.rows" :key="i" class="simple-row">
          <span>{{ i + 1 }}</span><b>{{ r.title }}</b><em>{{ r.artist || r.host }}</em>
          <small>{{ r.category || '' }}</small>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { state } from '../store'
</script>
