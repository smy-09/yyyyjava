<template>
  <section>
    <div class="page-head">
      <h2>🕘 最近播放</h2>
      <p>最近听过的歌曲，随时接着听</p>
    </div>
    <div class="section-title"><span>播放历史</span></div>
    <SongList :items="rows" empty-text="还没有播放记录" />
  </section>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { state, actions } from '../store'
import { api } from '../utils/request'
import SongList from './SongList.vue'

const list = ref([])
const rows = computed(() => list.value.map((s, pos) => {
  const i = state.songs.findIndex((x) => String(x.id) === String(s.id))
  return i >= 0 ? { i, pos: pos + 1 } : null
}).filter(Boolean))

onMounted(async () => {
  if (!state.online) return
  try {
    list.value = await api.history(100)
    // 本地音乐 / Jamendo 曲目刷新后可能不在当前队列，补入以便点播
    for (const s of list.value) await actions.ensureSongInQueue(s.id)
  } catch (e) {}
})
</script>
