<template>
  <aside class="sidebar">
    <div class="nav-group">发现音乐</div>
    <div class="nav-item" :class="{ active: state.view === 'home' }" @click="actions.showView('home')">
      <span class="ic">🏠</span><span>每日推荐</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'category' }" @click="actions.showView('category')">
      <span class="ic">🎵</span><span>歌曲分类</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'charts' }" @click="actions.showView('charts')">
      <span class="ic">🏆</span><span>排行榜</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'fav' }" @click="actions.showView('fav')">
      <span class="ic">❤️</span><span>我喜欢</span>
      <span class="badge">{{ state.profile.fav.length }}</span>
    </div>

    <div class="nav-group">K 歌 & 有声</div>
    <div class="nav-item" :class="{ active: state.view === 'accompaniment' }" @click="actions.showView('accompaniment')">
      <span class="ic">🎤</span><span>伴奏 K 歌</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'audiozone' }" @click="actions.showView('audiozone')">
      <span class="ic">📖</span><span>有声专区</span>
    </div>

    <div class="nav-group">我的音乐</div>
    <div class="nav-item" :class="{ active: state.view === 'local' }" @click="actions.showView('local')">
      <span class="ic">🎼</span><span>本地音乐</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'jamendo' }" @click="actions.showView('jamendo')">
      <span class="ic">🌍</span><span>Jamendo 曲库</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'playlist' }" @click="actions.showView('playlist')">
      <span class="ic">📃</span><span>我的歌单</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'history' }" @click="actions.showView('history')">
      <span class="ic">🕘</span><span>最近播放</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'tools' }" @click="actions.showView('tools')">
      <span class="ic">🛠️</span><span>音效与工具</span>
    </div>

    <div class="nav-group">设置</div>
    <div class="nav-item" :class="{ active: state.view === 'profile' }" @click="actions.showView('profile')">
      <span class="ic">👤</span><span>个人资料</span>
    </div>
    <div class="nav-item" :class="{ active: state.view === 'theme' }" @click="actions.showView('theme')">
      <span class="ic">🎨</span><span>外观设置</span>
    </div>

    <div class="nav-spacer"></div>
    <div class="nav-item" @click="actions.logout()">
      <span class="ic">⏻</span><span>退出登录</span>
    </div>
  </aside>
</template>

<script setup>
import { state, actions } from '../store'
</script>
