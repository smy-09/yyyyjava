<template>
  <section>
    <div class="page-head">
      <h2>📃 我的歌单</h2>
      <p>收藏歌单、自建歌单，把喜欢的音乐整理成自己的电台</p>
    </div>

    <div class="create-row">
      <input v-model="newName" class="mini-input" placeholder="新歌单名称…" @keyup.enter="create" />
      <button class="tiny-btn primary" @click="create">＋ 新建歌单</button>
    </div>

    <div class="section-title"><span>我创建的歌单</span><a @click="actions.loadPlaylists()">刷新</a></div>
    <div class="pl-grid">
      <div v-for="p in state.playlists.mine" :key="p.id" class="pl-card">
        <div class="pl-cover" :style="{ background: p.cover || coverStyle(p.id) }">🎵</div>
        <div class="pl-info">
          <div class="pl-name">{{ p.name }}</div>
          <div class="pl-sub">{{ p.songIds.length }} 首歌曲</div>
        </div>
        <span class="pl-del" @click="remove(p)">✕</span>
      </div>
      <div v-if="!state.playlists.mine.length" class="empty-box">还没有自建歌单，上面输入名称创建一个吧</div>
    </div>

    <div class="section-title" style="margin-top:26px"><span>官方精选歌单</span></div>
    <div class="pl-grid">
      <div v-for="p in state.playlists.system" :key="p.id" class="pl-card" @click="openSystem(p)">
        <div class="pl-cover" :style="{ background: p.cover }">🎧</div>
        <div class="pl-info">
          <div class="pl-name">{{ p.name }}</div>
          <div class="pl-sub">{{ p.description }}</div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { state, actions, coverStyle } from '../store'
import { player } from '../utils/player'

const newName = ref('')
function create() {
  if (!newName.value.trim()) return actions.toast('请输入歌单名称')
  if (!state.online) return actions.toast('自建歌单需要后端服务')
  fetch('/api/playlist', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-User-Id': state.userId },
    body: JSON.stringify({ name: newName.value.trim() })
  }).then((r) => r.json()).then((b) => {
    if (b.code === 200) { newName.value = ''; actions.loadPlaylists(); actions.toast('歌单已创建') }
  })
}
function remove(p) {
  if (!confirm(`删除歌单「${p.name}」？`)) return
  fetch(`/api/playlist/${p.id}`, { method: 'DELETE', headers: { 'X-User-Id': state.userId } })
    .then((r) => r.json()).then((b) => { if (b.code === 200) actions.loadPlaylists() })
}
function openSystem(p) {
  const list = state.songs.filter((s) => s.category === p.category || s.category === '有声')
  if (list.length) {
    state.categorySongs = list
    actions.showView('category')
    state.activeCategory = p.category
  } else actions.toast('该歌单暂无可播放歌曲')
}
onMounted(() => actions.loadPlaylists())
</script>
