<template>
  <div class="page feature-page">
    <div class="page-head">
      <div>
        <h2>🌍 Jamendo 正版曲库</h2>
        <p class="sub">来自全球的 CC 授权免费音乐，可合法播放——需配置开发者 client_id</p>
      </div>
      <button class="btn" @click="checkStatus" :disabled="checking">🔌 检查连接</button>
    </div>

    <div class="card setup-card" v-if="status && (!status.configured || !status.valid)">
      <div class="setup-title">⚙️ 配置 client_id（免费）</div>
      <ol class="steps">
        <li>打开 <a href="https://devportal.jamendo.com/admin/applications" target="_blank">Jamendo 开发者后台</a>，注册账号并登录</li>
        <li>创建应用（选 Read only 免费方案），拿到 <code>client_id</code></li>
        <li>填入后端 <code>backend/config.json</code> 的 <code>sources.jamendo.clientId</code>，重启后端</li>
      </ol>
      <div class="status-row err">{{ status.message }}</div>
    </div>

    <div class="card setup-card" v-if="status && status.valid">
      <div class="setup-title">同步曲目</div>
      <div class="input-row">
        <select v-model="genre">
          <option value="">全部风格</option>
          <option v-for="g in ['Rock','Jazz','Classical','Electronic','Hip Hop','Pop','Ambient','Folk','Blues','Metal','Reggae','Soundtrack']" :key="g" :value="g">{{ g }}</option>
        </select>
        <select v-model="limit">
          <option :value="50">50 首</option>
          <option :value="100">100 首</option>
          <option :value="200">200 首</option>
        </select>
        <button class="btn primary" @click="doSync" :disabled="syncing">{{ syncing ? '同步中…' : '⬇ 同步曲目' }}</button>
      </div>
      <div class="status-row" v-if="syncMsg">{{ syncMsg }}</div>
    </div>

    <div class="card">
      <div class="list-head">
        <div class="setup-title">曲库（{{ tracks.length }}）</div>
        <input v-model="keyword" @keyup.enter="loadTracks" placeholder="搜索歌曲 / 歌手 / 专辑" class="search-input" />
      </div>
      <div v-if="!tracks.length" class="empty">
        <div class="empty-icon">🌍</div>
        <p>还没有同步的曲目</p>
        <p class="hint">配置 client_id 后点「同步曲目」，即可拉取真实可播放的正版音乐</p>
      </div>
      <div v-else class="track-list">
        <div class="track" v-for="(t, i) in tracks" :key="t.id" @dblclick="play(t)">
          <div class="track-index">{{ String(i + 1).padStart(2, '0') }}</div>
          <img v-if="t.image" class="track-cover" :src="t.image" alt="" />
          <div v-else class="track-cover placeholder">🎵</div>
          <div class="track-info">
            <div class="track-title">{{ t.title }}</div>
            <div class="track-artist">{{ t.artist }}<span v-if="t.album"> · {{ t.album }}</span></div>
          </div>
          <div class="track-genre">{{ t.genre }}</div>
          <button class="btn small" @click.stop="play(t)">▶ 播放</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { api } from '../utils/request'
import { player } from '../utils/player'

const status = ref(null)
const checking = ref(false)
const syncing = ref(false)
const syncMsg = ref('')
const genre = ref('')
const limit = ref(100)
const keyword = ref('')
const tracks = ref([])

async function checkStatus() {
  checking.value = true
  try { status.value = await api.jamendoStatus() }
  catch (e) { status.value = { configured: false, valid: false, message: e.message } }
  finally { checking.value = false }
}
async function doSync() {
  syncing.value = true
  syncMsg.value = '正在从 Jamendo 拉取曲目…'
  try {
    const r = await api.jamendoSync({ genre: genre.value, limit: limit.value })
    syncMsg.value = `同步完成：${r.synced} 首`
    await loadTracks()
  } catch (e) { syncMsg.value = '同步失败：' + e.message }
  finally { syncing.value = false }
}
async function loadTracks() {
  try {
    const r = await api.jamendoTracks({ keyword: keyword.value, size: 200 })
    tracks.value = r.list || []
  } catch (e) { syncMsg.value = '加载失败：' + e.message }
}
function play(t) { player.playItem(t, 'jamendo') }
onMounted(() => { checkStatus(); loadTracks() })
</script>
