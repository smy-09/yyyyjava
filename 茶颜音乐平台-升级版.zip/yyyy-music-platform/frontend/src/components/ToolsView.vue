<template>
  <section>
    <div class="page-head">
      <h2>🛠️ 音效与播放器工具</h2>
      <p>蝰蛇音效 · 听歌识曲 · 本地音乐扫描 · 滚动/写真歌词 · 倍速播放 · 定时关闭</p>
    </div>

    <!-- 蝰蛇音效 -->
    <div class="section-title"><span>🐍 蝰蛇音效 · 招牌调音</span></div>
    <div class="effect-grid">
      <div v-for="e in state.effects" :key="e.id" class="effect-card"
           :class="{ on: state.playerSettings.effectId === e.id }" @click="chooseEffect(e)">
        <div class="effect-icon">{{ e.icon }}</div>
        <div class="effect-name">{{ e.name }}</div>
        <div class="effect-desc">{{ e.desc }}</div>
        <div class="effect-bars">
          <span v-for="(v, k) in e.params" :key="k" :title="k + ' ' + v + '%'"
                :style="{ height: Math.min(30, Math.max(4, v / 4)) + 'px' }"></span>
        </div>
      </div>
    </div>

    <div class="tool-cols">
      <!-- 听歌识曲 -->
      <div class="tool-card">
        <h3>🎵 听歌识曲</h3>
        <p class="tool-desc">哼唱识别 / 外界声音识别，输入歌名关键词或上传音频片段</p>
        <input v-model="recognizeHint" class="mini-input" placeholder="试试输入「晴天」或上传音频…" @keyup.enter="doRecognize" />
        <div class="tool-ops">
          <button class="tiny-btn primary" @click="doRecognize">🔍 开始识别</button>
          <label class="tiny-btn file-btn">上传音频<input type="file" accept="audio/*" @change="onAudioFile" hidden /></label>
        </div>
        <div v-for="(r, i) in state.recognizeResult" :key="i" class="recognize-row" @click="playRecognized(r)">
          <span class="rank">{{ i + 1 }}</span>
          <div class="rec-info">
            <div class="rec-title">{{ r.song?.title || r.title }}</div>
            <div class="rec-sub">{{ r.song?.artist || r.artist }} · {{ r.matchedBy || '识别结果' }}</div>
          </div>
          <span class="confidence">{{ r.confidence }}%</span>
        </div>
        <div v-if="!state.recognizeResult.length" class="empty-mini">识别结果会显示在这里</div>
      </div>

      <!-- 本地音乐扫描 -->
      <div class="tool-card">
        <h3>📂 本地音乐扫描</h3>
        <p class="tool-desc">选择本机音频文件，自动匹配曲库并加入播放列表</p>
        <label class="upload-box">
          <div class="upload-icon">📁</div>
          <div>点击选择音频文件（可多选）</div>
          <input type="file" multiple accept="audio/*" hidden @change="onScanFiles" />
        </label>
        <div v-if="state.localScanResult" class="scan-result">
          <b>扫描结果：</b>共 {{ state.localScanResult.total }} 个文件，匹配 {{ state.localScanResult.matched.length }} 首
          <div v-for="(m, i) in state.localScanResult.matched.slice(0, 8)" :key="i" class="scan-row">
            ✅ {{ m.file }} → {{ m.song.title }}
          </div>
          <div v-if="state.localScanResult.unmatched.length" class="scan-unmatched">
            未匹配 {{ state.localScanResult.unmatched.length }} 个文件
          </div>
        </div>
      </div>

      <!-- 播放器设置 -->
      <div class="tool-card">
        <h3>⚙️ 播放器设置</h3>
        <p class="tool-desc">倍速播放、歌词模式、定时关闭</p>
        <div class="setting-line">
          <span>播放倍速</span>
          <div class="speed-btns">
            <span v-for="s in [0.5, 0.75, 1, 1.25, 1.5, 2, 3]" :key="s" class="speed-btn"
                  :class="{ on: state.playerSettings.speed === s }" @click="setSpeed(s)">{{ s }}x</span>
          </div>
        </div>
        <div class="setting-line">
          <span>歌词模式</span>
          <div class="speed-btns">
            <span class="speed-btn" :class="{ on: state.playerSettings.lyricMode === 'rolling' }" @click="setLyric('rolling')">滚动歌词</span>
            <span class="speed-btn" :class="{ on: state.playerSettings.lyricMode === 'photo' }" @click="setLyric('photo')">写真歌词</span>
          </div>
        </div>
        <div class="setting-line">
          <span>定时关闭</span>
          <div class="speed-btns">
            <span v-for="m in [0, 10, 20, 30, 60, 90]" :key="m" class="speed-btn"
                  :class="{ on: sleepMin === m }" @click="setTimer(m)">{{ m === 0 ? '关闭' : m + '分' }}</span>
          </div>
        </div>
        <div v-if="state.sleepTimer.enabled" class="timer-hint">
          ⏰ {{ state.sleepTimer.remainingMinutes != null ? `剩余 ${state.sleepTimer.remainingMinutes} 分钟` : `${state.sleepTimer.minutes} 分钟后关闭` }}
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { state, actions } from '../store'
import { player } from '../utils/player'

const recognizeHint = ref('')
const sleepMin = ref(0)

function chooseEffect(e) {
  // 再次点击同一音效则关闭（还原原声）
  const target = state.playerSettings.effectId === e.id ? 'original' : e.id
  player.setEffect(target)
  actions.toast(target === 'original' ? '已还原原声' : `已启用「${e.name}」音效`)
}
function doRecognize() {
  if (!recognizeHint.value.trim()) return actions.toast('请输入关键词或上传音频')
  actions.recognize({ hint: recognizeHint.value })
}
function onAudioFile(e) {
  const file = e.target.files[0]
  if (!file) return
  const reader = new FileReader()
  reader.onload = () => {
    const raw = String(reader.result || '')
    actions.recognize({ filename: file.name, audioBase64: raw.slice(raw.indexOf(',') + 1, raw.indexOf(',') + 60000) })
  }
  reader.readAsDataURL(file)
}
function playRecognized(r) {
  const song = r.song || r
  if (song.id) player.playItem(song, 'song')
}
function onScanFiles(e) {
  const files = Array.from(e.target.files || []).map((f) => ({ name: f.name, size: f.size }))
  if (files.length) actions.scanLocal(files)
}
function setSpeed(s) { player.setSpeed(s); actions.toast(`播放倍速：${s}x`) }
function setLyric(mode) {
  state.playerSettings.lyricMode = mode
  actions.savePlayerSettings({ lyricMode: mode })
  actions.toast(mode === 'rolling' ? '已切换滚动歌词' : '已切换写真歌词')
}
async function setTimer(m) {
  await actions.setSleepTimer(m)
  sleepMin.value = m
}
onMounted(() => {
  if (!state.effects.length && state.online) actions.loadPlayerSettings()
  sleepMin.value = state.sleepTimer?.minutes || 0
})
</script>
