<template>
  <section>
    <div class="page-head">
      <h2>排行榜</h2>
      <p>热歌榜、飙升榜、新歌榜 —— 数据来自全站播放行为统计</p>
    </div>

    <div class="chip-row">
      <span v-for="t in tabs" :key="t.id" class="chip" :class="{ on: state.activeChart === t.id }"
            @click="switchChart(t.id)">{{ t.name }}</span>
    </div>

    <div class="section-title"><span>{{ currentName }} · TOP {{ rows.length }}</span><a @click="playAll">▶ 播放全部</a></div>
    <SongList :items="rows" empty-text="榜单加载中…" />
  </section>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { state, actions } from '../store'
import { player } from '../utils/player'
import SongList from './SongList.vue'

const tabs = [
  { id: 'hot', name: '热歌榜' },
  { id: 'rising', name: '飙升榜' },
  { id: 'new', name: '新歌榜' },
  { id: 'original', name: '原创榜' }
]
const currentName = computed(() => tabs.find((t) => t.id === state.activeChart)?.name || '热歌榜')
const rows = computed(() => (state.charts[state.activeChart] || []).map((s, pos) => {
  const i = state.songs.findIndex((x) => x.id === s.id)
  return i >= 0 ? { i, pos: pos + 1 } : null
}).filter(Boolean))

function switchChart(id) { actions.loadChart(id) }
function playAll() { if (rows.value.length) player.play(rows.value[0].i) }
onMounted(() => {
  if (!state.charts.hot.length) actions.loadChart('hot')
})
</script>
