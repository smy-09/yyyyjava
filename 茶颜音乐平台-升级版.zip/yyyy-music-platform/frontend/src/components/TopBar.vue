<template>
  <header class="topbar">
    <div class="logo"><span class="mark">🎵</span><span><b>茶颜</b>音乐</span></div>

    <div class="search" @keydown.enter="actions.doSearch(state.filter)">
      <input v-model="state.filter" placeholder="搜索歌曲、歌手、伴奏、有声内容…" />
    </div>

    <div class="top-actions">
      <span class="net-dot" :class="state.online ? 'on' : 'off'"
            :title="state.online ? '后端已连接（数据存 MySQL 风格文件库）' : '后端未连接（本地演示模式）'"></span>
      <span class="link" @click="actions.showView('tools')">蝰蛇音效</span>
      <span class="link" @click="actions.toast('演示版本未接入支付')">开通VIP</span>
      <span class="nick" @click="actions.showView('profile')">{{ state.profile.nickname }}</span>
      <div class="ava" :style="{ background: avatarBg(state.profile.avatar) }"
           :title="state.profile.nickname" @click="actions.showView('profile')">
        {{ avatarText(state.profile.avatar) }}
      </div>
      <span class="link" @click="actions.logout()">退出</span>
    </div>
  </header>
</template>

<script setup>
import { state, actions, avatarBg, avatarText } from '../store'
</script>
