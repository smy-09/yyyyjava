<template>
  <section>
    <section class="hero">
      <h2>{{ state.profile.nickname }} · 每日推荐</h2>
      <p>624 首歌曲 · 320 首伴奏 · 260 档有声节目，AI 根据你的口味持续更新。</p>
      <div class="hero-ops">
        <button class="play-hero" @click="player.play(0)">▶ 播放全部</button>
        <button class="play-hero ghost" @click="actions.loadRecommend()">🔄 换一批推荐</button>
      </div>
    </section>

    <!-- 分类速览 -->
    <div class="section-title"><span>歌曲分类</span><a @click="actions.showView('category')">查看全部 →</a></div>
    <div class="cat-grid">
      <div v-for="c in state.categories" :key="c.name" class="cat-card"
           :style="{ background: c.cover }" @click="actions.showCategory(c.name)">
        <span class="cat-icon">{{ c.icon }}</span>
        <div class="cat-name">{{ c.name }}</div>
        <div class="cat-count">{{ c.count }} 首</div>
      </div>
    </div>

    <!-- AI 推荐 -->
    <div class="section-title"><span>AI 推荐 · 猜你喜欢</span><a @click="actions.showView('charts')">更多榜单 →</a></div>
    <SongList :items="recommendRows" empty-text="正在生成推荐…" />

    <!-- 热歌榜前 10 -->
    <div class="section-title"><span>热歌榜 TOP 10</span><a @click="actions.showView('charts')">完整榜单 →</a></div>
    <SongList :items="hotRows" empty-text="暂无榜单数据" />
  </section>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { state, actions } from '../store'
import { player } from '../utils/player'
import SongList from './SongList.vue'

const indexById = (id) => state.songs.findIndex((s) => s.id === id)
const recommendRows = computed(() =>
  state.recommends.map((s, pos) => ({ i: indexById(s.id), pos: pos + 1 })).filter((x) => x.i >= 0).slice(0, 30)
)
const hotRows = computed(() =>
  (state.charts.hot || []).slice(0, 10).map((s, pos) => ({ i: indexById(s.id), pos: pos + 1 })).filter((x) => x.i >= 0)
)

onMounted(() => {
  if (state.recommends.length === 0) actions.loadRecommend()
})
</script>
