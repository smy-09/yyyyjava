<template>
  <footer class="player">
    <div class="p-left">
      <div class="cover" :style="cur >= 0 ? coverStyle(cur) : ''"></div>
      <div class="meta">
        <div class="t">{{ cur >= 0 && state.songs[cur] ? state.songs[cur].title : '—' }}</div>
        <div class="a">{{ cur >= 0 && state.songs[cur] ? state.songs[cur].artist : '—' }}</div>
      </div>
    </div>

    <div class="p-center">
      <div class="controls">
        <button class="btn" title="上一首" @click="player.prev()">⏮</button>
        <button class="btn play" title="播放/暂停" @click="player.toggle()">{{ state.playing ? '⏸' : '▶' }}</button>
        <button class="btn" title="下一首" @click="player.next()">⏭</button>
      </div>
      <div class="progress">
        <span class="time">{{ fmt(state.curTime) }}</span>
        <div class="bar" @click="onSeek">
          <div class="fill" :style="{ width: pct + '%' }"></div>
          <div class="knob" :style="{ left: pct + '%' }"></div>
        </div>
        <span class="time">{{ fmt(cur >= 0 && state.songs[cur] ? state.songs[cur].dur : 0) }}</span>
      </div>
    </div>

    <div class="p-right">
      <span class="quick" title="倍速播放" @click="cycleSpeed">{{ state.playerSettings.speed }}x</span>
      <span class="quick" title="蝰蛇音效" @click="actions.showView('tools')">🐍</span>
      <span class="quick" :class="{ warm: state.sleepTimer.enabled }" title="定时关闭" @click="cycleTimer">
        {{ state.sleepTimer.enabled ? `⏰${state.sleepTimer.remainingMinutes ?? state.sleepTimer.minutes}` : '⏰' }}
      </span>
      <div class="mode" title="播放模式" @click="player.cycleMode()">{{ modeNames[state.mode] }}</div>
      <div class="vol">
        🔊
        <div class="bar" @click="onVol">
          <div class="fill" :style="{ width: state.volume * 100 + '%' }"></div>
          <div class="knob" :style="{ left: state.volume * 100 + '%' }"></div>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { computed } from 'vue'
import { state, actions, coverStyle, fmt } from '../store'
import { player } from '../utils/player'

const modeNames = ['顺序', '随机', '单曲']
const cur = computed(() => state.current)
const pct = computed(() => {
  const curSong = cur.value >= 0 ? state.songs[cur.value] : null
  const total = state.duration || (curSong ? curSong.dur : 0)
  return total ? Math.min(100, (state.curTime / total) * 100) : 0
})
const ratioOf = (e) => {
  const r = e.currentTarget.getBoundingClientRect()
  return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width))
}
const onSeek = (e) => player.seek(ratioOf(e))
const onVol = (e) => player.setVolume(ratioOf(e))

const speeds = [1, 1.25, 1.5, 2, 0.75, 0.5]
function cycleSpeed() {
  const i = speeds.indexOf(Number(state.playerSettings.speed))
  const next = speeds[(i + 1) % speeds.length]
  player.setSpeed(next)
  actions.toast(`播放倍速：${next}x`)
}
const timers = [0, 10, 20, 30, 60]
function cycleTimer() {
  const i = timers.indexOf(Number(state.sleepTimer?.minutes || 0))
  const next = timers[(i + 1) % timers.length]
  actions.setSleepTimer(next)
}
</script>
