<template>
  <section>
    <div class="page-head">
      <h2>🔍 搜索结果</h2>
      <p>关键词「{{ state.filter }}」· 歌曲 {{ state.searchResult.songs.length }} · 伴奏 {{ state.searchResult.accompaniments.length }} · 有声 {{ state.searchResult.audioZone.length }}</p>
    </div>

    <div class="section-title"><span>歌曲</span></div>
    <SongList :items="songRows" empty-text="没有找到匹配的歌曲" />

    <template v-if="state.searchResult.accompaniments.length">
      <div class="section-title"><span>伴奏</span></div>
      <div class="simple-list">
        <div v-for="a in state.searchResult.accompaniments.slice(0, 30)" :key="a.id" class="simple-row" @click="player.playItem(a, 'acc')">
          <span>🎤</span><b>{{ a.title }}</b><em>{{ a.artist }}</em><small>{{ a.quality }}</small>
        </div>
      </div>
    </template>

    <template v-if="state.searchResult.audioZone.length">
      <div class="section-title"><span>有声内容</span></div>
      <div class="simple-list">
        <div v-for="a in state.searchResult.audioZone.slice(0, 30)" :key="a.id" class="simple-row" @click="player.playItem(a, 'az')">
          <span>📖</span><b>{{ a.title }}</b><em>{{ a.host }}</em><small>{{ a.category }}</small>
        </div>
      </div>
    </template>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { state } from '../store'
import { player } from '../utils/player'
import SongList from './SongList.vue'

const songRows = computed(() => state.searchResult.songs.map((s, pos) => {
  const i = state.songs.findIndex((x) => x.id === s.id)
  return i >= 0 ? { i, pos: pos + 1 } : null
}).filter(Boolean))
</script>
