<template>
  <section>
    <div class="page-head">
      <h2>🎤 伴奏 · K 歌</h2>
      <p>海量 K 歌伴奏，支持录歌、实时修音、调音与混响。选一首伴奏，点击「录歌」即可开始。</p>
    </div>

    <div class="chip-row">
      <span class="chip" :class="{ on: !accFilter }" @click="pick('')">全部伴奏</span>
      <span v-for="c in state.accCategories" :key="c.name" class="chip"
            :class="{ on: accFilter === c.name }" @click="pick(c.name)">
        {{ c.name }} <small>{{ c.count }}</small>
      </span>
    </div>

    <div class="section-title">
      <span>伴奏曲库 · {{ rows.length }} 首</span>
      <input v-model="accKeyword" class="mini-input" placeholder="搜索伴奏…" @keyup.enter="search" />
    </div>

    <div class="acc-grid">
      <div v-for="a in rows" :key="a.id" class="acc-card">
        <div class="acc-cover" :style="{ background: a.cover || coverStyle(a.id) }">
          <span class="acc-play" @click="player.playItem(a, 'acc')">▶</span>
        </div>
        <div class="acc-info">
          <div class="acc-title">{{ a.title }}</div>
          <div class="acc-sub">{{ a.artist }} · {{ a.key }} 调 · {{ a.bpm }} BPM</div>
          <div class="acc-tags">
            <span class="tag">{{ a.quality }}</span>
            <span class="tag" v-if="a.hasGuideVocal">导唱</span>
          </div>
        </div>
        <button class="rec-btn" @click="openRecord(a)">● 录歌</button>
      </div>
    </div>

    <!-- 我的录音 -->
    <div class="section-title" style="margin-top:28px">
      <span>我的录音 · {{ state.recordings.length }} 条</span>
      <a @click="actions.loadRecordings()">刷新</a>
    </div>
    <div v-if="!state.recordings.length" class="empty-box">还没有录音，点上面的「● 录歌」开始吧 🎤</div>
    <div v-for="r in state.recordings" :key="r.id" class="rec-item">
      <div class="rec-main">
        <div class="rec-title">{{ r.title }}</div>
        <div class="rec-sub">{{ r.key }} 调 · {{ fmtTime(r.duration) }} · {{ r.createdAt.slice(0, 16).replace('T', ' ') }}</div>
      </div>
      <div class="tune-controls">
        <label>升降调 <b>{{ r.pitch > 0 ? '+' : '' }}{{ r.pitch }}</b>
          <input type="range" min="-6" max="6" :value="r.pitch" @change="tune(r, { pitch: +$event.target.value })" />
        </label>
        <label>修音强度 <b>{{ r.strength }}%</b>
          <input type="range" min="0" max="100" :value="r.strength" @change="tune(r, { strength: +$event.target.value })" />
        </label>
        <label>混响 <b>{{ r.reverb }}%</b>
          <input type="range" min="0" max="100" :value="r.reverb" @change="tune(r, { reverb: +$event.target.value })" />
        </label>
        <button class="tiny-btn" :class="{ on: r.autoTune }" @click="tune(r, { autoTune: !r.autoTune })">
          自动修音 {{ r.autoTune ? '开' : '关' }}
        </button>
      </div>
    </div>

    <!-- 录歌弹窗 -->
    <div v-if="recordTarget" class="modal-mask" @click.self="recordTarget = null">
      <div class="modal">
        <div class="modal-head">录歌 · {{ recordTarget.title }} <span @click="recordTarget = null">✕</span></div>
        <div class="modal-body">
          <div class="record-stage">
            <div class="wave" :class="{ active: recording }">
              <span v-for="n in 36" :key="n" :style="{ height: (10 + ((n * 17) % 34)) + 'px' }"></span>
            </div>
            <div class="record-status">{{ recording ? '● 正在录制…再次点击停止' : '点击下方按钮开始录制' }}</div>
            <button class="big-rec" :class="{ active: recording }" @click="toggleRecord">
              {{ recording ? '■ 停止并保存' : '● 开始录歌' }}
            </button>
          </div>
          <div class="form-row">
            <label>调性
              <select v-model="recordForm.key">
                <option v-for="k in ['C','D','E','F','G','A','B','Am','Em','Dm','Gm']" :key="k">{{ k }}</option>
              </select>
            </label>
            <label>升降调 <b>{{ recordForm.pitch > 0 ? '+' : '' }}{{ recordForm.pitch }}</b>
              <input type="range" min="-6" max="6" v-model.number="recordForm.pitch" />
            </label>
          </div>
          <label class="check-line"><input type="checkbox" v-model="recordForm.autoTune" /> 开启实时修音（自动准调）</label>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref, onMounted, watch } from 'vue'
import { state, actions, coverStyle } from '../store'
import { player } from '../utils/player'

const accFilter = ref('')
const accKeyword = ref('')
const recordTarget = ref(null)
const recording = ref(false)
const recordForm = ref({ key: 'C', pitch: 0, autoTune: true, duration: 0 })
let timer = null

const rows = computed(() => state.accList)
const fmtTime = (s) => {
  const n = Math.floor(s || 0)
  return `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}`
}

function pick(name) { accFilter.value = name; actions.loadAccompaniments(name, accKeyword.value) }
function search() { actions.loadAccompaniments(accFilter.value, accKeyword.value) }

function openRecord(a) {
  recordTarget.value = a
  recordForm.value = { key: a.key, pitch: 0, autoTune: true, duration: a.duration }
  recording.value = false
}
function toggleRecord() {
  if (!recording.value) {
    recording.value = true
    recordForm.value.duration = 0
    timer = setInterval(() => { recordForm.value.duration += 1 }, 1000)
    player.playItem(recordTarget.value, 'acc')
  } else {
    clearInterval(timer)
    recording.value = false
    const target = recordTarget.value
    recordTarget.value = null
    actions.recordSong(target.id, recordForm.value)
  }
}
function tune(r, patch) { actions.tuneRecording(r.id, patch) }

watch(() => state.view, (v) => {
  if (v === 'accompaniment' && !state.accList.length) actions.loadAccompaniments()
}, { immediate: true })
onMounted(() => {
  if (!state.accList.length) actions.loadAccompaniments()
})
</script>
