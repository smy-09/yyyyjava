@echo off
chcp 65001 >nul
title 音乐平台 - 一键启动
cd /d "%~dp0"

echo ============================================
echo   音乐平台启动中...
echo ============================================

if not exist "%~dp0backend\node_modules\mysql2" (
  echo 正在安装后端依赖（首次启动，请稍候）...
  cd /d "%~dp0backend"
  npm install --registry=https://registry.npmmirror.com
  cd /d "%~dp0"
)

if not exist "%~dp0frontend\node_modules\vite" (
  echo 正在安装前端依赖（首次启动，请稍候）...
  cd /d "%~dp0frontend"
  npm install --registry=https://registry.npmmirror.com
  cd /d "%~dp0"
)

start "音乐平台后端 (8080)" cmd /k "cd /d "%~dp0backend" && node server.js"
timeout /t 2 >nul

start "音乐平台前端 (5173)" cmd /k "cd /d "%~dp0frontend" && npm run dev"

echo.
echo 服务已启动，请打开浏览器访问:
echo   http://localhost:5173
echo.
echo 演示账号: demo / 123456
echo 关闭对应的黑窗口即可停止服务。
echo.
pause
